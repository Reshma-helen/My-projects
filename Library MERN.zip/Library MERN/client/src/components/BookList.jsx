// import { useEffect, useState } from 'react';
// import axios from 'axios';
// import { Table, Container, Button, Modal, Form ,Navbar,Nav} from 'react-bootstrap';
// import {useNavigate} from 'react-router-dom'

// function BookList() {
//   const [books, setBooks] = useState([]);
//   const [selectedBook, setSelectedBook] = useState(null);
//   const [showEditModal, setShowEditModal] = useState(false);

//   const fetchBooks = async () => {
//     const res = await axios.get('http://localhost:5000/books');
//     setBooks(res.data.books);
//   };

//   useEffect(() => {
//     fetchBooks();
//   }, []);

//   const deleteBook = async (id) => {
//     if (window.confirm('Are you sure you want to delete this book?')) {
//       await axios.delete(`http://localhost:5000/books/${id}`);
//       fetchBooks(); // refresh list
//     }
//   };

//   const handleEditClick = (book) => {
//     setSelectedBook(book);
//     setShowEditModal(true);
//   };

//   const handleEditChange = (e) => {
//     setSelectedBook({ ...selectedBook, [e.target.name]: e.target.value });
//   };

//   const saveEditedBook = async () => {
//     await axios.put(`http://localhost:5000/books/${selectedBook._id}`, selectedBook);
//     setShowEditModal(false);
//     fetchBooks();
//   };

//     const navigate=useNavigate()
//    const handleLogout = async() => {
     
//       // alert('You have been logged out.');
//       // navigate('/login');
  
//        try {
//         await axios.post('http://localhost:5000/logout'); // optional
//       } catch (error) {
//         console.error('Logout error:', error);
//       }
  
//       localStorage.removeItem('isLoggedIn'); // remove flag
//       navigate('/login'); // redirect
//     };


//   return (

//     <>

//      <Navbar bg="dark" variant="dark" expand="lg" sticky="top">
//     <Container>
//       <Navbar.Brand href="#">Book Management</Navbar.Brand>
//       <Navbar.Toggle aria-controls="nav" />
//       <Navbar.Collapse id="nav">
//         <Nav className="ms-auto">
//           <Nav.Link href="/dashboard">Home</Nav.Link>
//            <Nav.Link href="/addbook">Add Books</Nav.Link>
//           <Nav.Link href="/booklist">View Book List</Nav.Link>
//           <Nav.Link href="/dashboard">Contact</Nav.Link>
//           <Nav.Link onClick={handleLogout} style={{ cursor: 'pointer' }}> Logout </Nav.Link>
//         </Nav>
//       </Navbar.Collapse>
//     </Container>
//   </Navbar>
    

//     <Container className="mt-4">
//       <h2>Book List</h2>
//       <Table striped bordered hover responsive>
//         <thead>
//           <tr>
//             <th>Title</th>
//             <th>Author</th>
//             <th>Quantity</th>
//             <th>Genre</th>
//             <th>Year</th>
//             <th>Edition</th>
//             <th>Price</th>
//             <th>Cover Type</th>
//             <th>Image</th>
//             <th>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {books.map((book) => (
//             <tr key={book._id}>
//               <td>{book.bookTitle}</td>
//               <td>{book.bookAuthor}</td>
//               <td>{book.bookQuantity}</td>
//               <td>{book.bookGenre}</td>
//               <td>{book.bookYOP}</td>
//               <td>{book.bookEdition}</td>
//               <td>{book.bookPrice}</td>
//               <td>{book.bookCoverType}</td>
//                <td>
//                 {book.bookImage ? (
//                   <img
//                     src={book.bookImage}
//                     alt={book.bookTitle}
//                     style={{ width: '60px', height: '80px', objectFit: 'cover' }}
//                   />
//                 ) : (
//                   'No image'
//                 )}
//               </td>
//               <td className="text-center align-middle p-2">
//                 <div className="d-flex justify-content-center align-items-center gap-2">
//                     <Button variant="warning" size="sm" onClick={() => handleEditClick(book)}>Edit</Button>
//                     <Button variant="danger" size="sm" onClick={() => deleteBook(book._id)}>Delete</Button>
//                 </div>
//                 </td>

//             </tr>
//           ))}
//         </tbody>
//       </Table>

//       {/* Edit Modal */}
//       <Modal show={showEditModal} onHide={() => setShowEditModal(false)}>
//         <Modal.Header closeButton>
//           <Modal.Title>Edit Book</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           {selectedBook && (
//             <Form>
//               <Form.Group className="mb-2">
//                 <Form.Label>Title</Form.Label>
//                 <Form.Control name="bookTitle" value={selectedBook.bookTitle} onChange={handleEditChange} />
//               </Form.Group>
//               <Form.Group className="mb-2">
//                 <Form.Label>Author</Form.Label>
//                 <Form.Control name="bookAuthor" value={selectedBook.bookAuthor} onChange={handleEditChange}  />
//               </Form.Group>
//               <Form.Group className="mb-2">
//                 <Form.Label>Quantity</Form.Label>
//                 <Form.Control name="bookQuantity" value={selectedBook.bookQuantity} onChange={handleEditChange} />
//               </Form.Group>
//               <Form.Group className="mb-2">
//                 <Form.Label>Genre</Form.Label>
//                 <Form.Control name="bookGenre" value={selectedBook.bookGenre} onChange={handleEditChange} />
//               </Form.Group>
//               <Form.Group className="mb-2">
//                 <Form.Label>Year</Form.Label>
//                 <Form.Control name="bookYOP" value={selectedBook.bookYOP} onChange={handleEditChange} />
//               </Form.Group>
//               <Form.Group className="mb-2">
//                 <Form.Label>Edition</Form.Label>
//                 <Form.Control name="bookEdition" value={selectedBook.bookEdition} onChange={handleEditChange} />
//               </Form.Group>
//               <Form.Group className="mb-2">
//                 <Form.Label>Price</Form.Label>
//                 <Form.Control name="bookPrice" value={selectedBook.bookPrice} onChange={handleEditChange} />
//               </Form.Group>
//               <Form.Group className="mb-2">
//                 <Form.Label>Cover Type</Form.Label>
//                 <Form.Control name="bookCoverType" value={selectedBook.bookCoverType} onChange={handleEditChange} />
//               </Form.Group>
//               <Form.Group className="mb-2">
//                 <Form.Label>Image URL</Form.Label>
//                 <Form.Control name="bookImage" value={selectedBook.bookImage} onChange={handleEditChange} />
//               </Form.Group>
//             </Form>
//           )}
//         </Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={() => setShowEditModal(false)}>Cancel</Button>
//           <Button variant="primary" onClick={saveEditedBook}>Save Changes</Button>
//         </Modal.Footer>
//       </Modal>
//     </Container>

//       </>
//   );
    
// }

// export default BookList;



import { useEffect, useState } from 'react';
import axios from 'axios';
import { Table, Container, Button, Modal, Form, Navbar, Nav } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

function BookList() {
  const [books, setBooks] = useState([]);
  const [selectedBook, setSelectedBook] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const navigate = useNavigate();

  const fetchBooks = async () => {
    const res = await axios.get('http://localhost:5000/books');
    setBooks(res.data.books);
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  const deleteBook = async (id) => {
    if (window.confirm('Are you sure you want to delete this book?')) {
      await axios.delete(`http://localhost:5000/books/${id}`);
      fetchBooks();
    }
  };

  const handleEditClick = (book) => {
    setSelectedBook(book);
    setShowEditModal(true);
  };

  const handleEditChange = (e) => {
    setSelectedBook({ ...selectedBook, [e.target.name]: e.target.value });
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:5000/books/${selectedBook._id}`, selectedBook);
      setShowEditModal(false);
      fetchBooks();
    } catch (error) {
      console.error('Error updating book:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await axios.post('http://localhost:5000/logout');
    } catch (error) {
      console.error('Logout error:', error);
    }
    localStorage.removeItem('isLoggedIn');
    navigate('/login');
  };




  return (
    <>
      {/* Navbar */}
      <Navbar bg="dark" variant="dark" expand="lg" sticky="top">
        <Container>
          <Navbar.Brand href="#">Book Management</Navbar.Brand>
          <Navbar.Toggle aria-controls="nav" />
          <Navbar.Collapse id="nav">
            <Nav className="ms-auto">
              <Nav.Link href="/dashboard">Home</Nav.Link>
              <Nav.Link href="/addbook">Add Books</Nav.Link>
              <Nav.Link href="/booklist">View Book List</Nav.Link>
              <Nav.Link href="/dashboard">Contact</Nav.Link>
              <Nav.Link onClick={handleLogout} style={{ cursor: 'pointer' }}> Logout </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Book List */}
      <Container className="mt-4">
        <h2>Book List</h2>
        <Table striped bordered hover responsive>
          <thead>
            <tr>
              <th>Title</th>
              <th>Author</th>
              <th>Quantity</th>
              <th>Genre</th>
              <th>Year</th>
              <th>Edition</th>
              <th>Price</th>
              <th>Cover Type</th>
              <th>Image</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {books.map((book) => (
              <tr key={book._id}>
                <td>{book.bookTitle}</td>
                <td>{book.bookAuthor}</td>
                <td>{book.bookQuantity}</td>
                <td>{book.bookGenre}</td>
                <td>{book.bookYOP}</td>
                <td>{book.bookEdition}</td>
                <td>{book.bookPrice}</td>
                <td>{book.bookCoverType}</td>
                <td>
                  {book.bookImage ? (
                    <img
                      src={book.bookImage}
                      alt={book.bookTitle}
                      style={{ width: '60px', height: '80px', objectFit: 'cover' }}
                    />
                  ) : (
                    'No image'
                  )}
                </td>
                <td className="text-center align-middle p-2">
                  <div className="d-flex justify-content-center align-items-center gap-2">
                    {/* <Button variant="success" size="sm">Add To Cart</Button> */}
                    <Button variant="primary" size="sm" onClick={() => handleEditClick(book)}>Edit</Button>
                    <Button variant="danger" size="sm" onClick={() => deleteBook(book._id)}>Delete</Button>
                    
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>

        {/* Edit Modal */}
        <Modal show={showEditModal} onHide={() => setShowEditModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>Edit Book</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {selectedBook && (
              <Form onSubmit={handleEditSubmit}>
                <Form.Group className="mb-2">
                  <Form.Label>Title</Form.Label>
                  <Form.Control
                    name="bookTitle"
                    value={selectedBook.bookTitle}
                    onChange={handleEditChange}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-2">
                  <Form.Label>Author</Form.Label>
                  <Form.Control
                    name="bookAuthor"
                    value={selectedBook.bookAuthor}
                    onChange={handleEditChange}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-2">
                  <Form.Label>Quantity</Form.Label>
                  <Form.Control
                    type="number"
                    name="bookQuantity"
                    value={selectedBook.bookQuantity}
                    onChange={handleEditChange}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-2">
                  <Form.Label>Genre</Form.Label>
                  <Form.Control
                    name="bookGenre"
                    value={selectedBook.bookGenre}
                    onChange={handleEditChange}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-2">
                  <Form.Label>Year</Form.Label>
                  <Form.Control
                    type="number"
                    name="bookYOP"
                    value={selectedBook.bookYOP}
                    onChange={handleEditChange}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-2">
                  <Form.Label>Edition</Form.Label>
                  <Form.Control
                    name="bookEdition"
                    value={selectedBook.bookEdition}
                    onChange={handleEditChange}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-2">
                  <Form.Label>Price</Form.Label>
                  <Form.Control
                    type="number"
                    name="bookPrice"
                    value={selectedBook.bookPrice}
                    onChange={handleEditChange}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-2">
                  <Form.Label>Cover Type</Form.Label>
                  <Form.Control
                    name="bookCoverType"
                    value={selectedBook.bookCoverType}
                    onChange={handleEditChange}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-2">
                  <Form.Label>Image URL</Form.Label>
                  <Form.Control
                    name="bookImage"
                    value={selectedBook.bookImage}
                    onChange={handleEditChange}
                    required
                  />
                </Form.Group>

                <Modal.Footer className="px-0">
                  <Button variant="secondary" onClick={() => setShowEditModal(false)}>Cancel</Button>
                  <Button variant="primary" type="submit">Save Changes</Button>
                </Modal.Footer>
              </Form>
            )}
          </Modal.Body>
        </Modal>
      </Container>
    </>
  );
}

export default BookList;
