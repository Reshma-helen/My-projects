import { useState } from 'react';
import axios from 'axios';
import { Form, Button, Container, Row, Col, Card ,Navbar,Nav} from 'react-bootstrap';
import {useNavigate} from 'react-router-dom'

function AddBook() {
  const [book, setBook] = useState({
    bookTitle: "",
    bookAuthor: "",
    bookQuantity: "",
    bookGenre: "",
    bookYOP: "",
    bookEdition: "",
    bookPrice: "",
    bookCoverType: "",
    bookImage: ""
  });

  const handleChange = (e) => {
    setBook({ ...book, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    try {
      const res = await axios.post('http://localhost:5000/addbook', book);
      alert(res.data.message);

      // Reset the form
      setBook({
        bookTitle: "",
        bookAuthor: "",
        bookQuantity: "",
        bookGenre: "",
        bookYOP: "",
        bookEdition: "",
        bookPrice: "",
        bookCoverType: "",
        bookImage: ""
      });
    } catch (error) {
      console.error(error);
      alert("Failed to add book");
    }
  };

  const navigate=useNavigate()

  const handleLogout = async() => {
   
    // alert('You have been logged out.');
    // navigate('/login');

     try {
      await axios.post('http://localhost:5000/logout'); // optional
    } catch (error) {
      console.error('Logout error:', error);
    }

    localStorage.removeItem('isLoggedIn'); // remove flag
    navigate('/login'); // redirect
  };

  return (

    <>
    

    <Navbar bg="dark" variant="dark" expand="lg" sticky="top">
        <Container>
          <Navbar.Brand href="#">Book Management</Navbar.Brand>
          <Navbar.Toggle aria-controls="nav" />
          <Navbar.Collapse id="nav">
            <Nav className="ms-auto">
              <Nav.Link href="/dashboard">Home</Nav.Link>
               <Nav.Link href="/addbook">Add Books</Nav.Link>
              <Nav.Link href="/booklist">View Book List</Nav.Link>
              <Nav.Link href="/dashboard#contact">Contact</Nav.Link>
              <Nav.Link onClick={handleLogout} style={{ cursor: 'pointer' }}> Logout </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    
    
  


    {/* <Container className="mt-5">
      <Row className="justify-content-md-center">
        <Col md={8}>
          <Card>
            <Card.Body>
              <Card.Title className="text-center mb-4">Add New Book</Card.Title>
              <Form>
                {[
                  { label: 'Title', name: 'bookTitle' },
                  { label: 'Author', name: 'bookAuthor' },
                  { label: 'Quantity', name: 'bookQuantity', type: 'number' },
                  { label: 'Genre', name: 'bookGenre' },
                  { label: 'Year of Publication', name: 'bookYOP', type: 'number' },
                  { label: 'Edition', name: 'bookEdition' },
                  { label: 'Price', name: 'bookPrice', type: 'number' },
                  { label: 'Cover Type', name: 'bookCoverType' },
                  { label: 'Image URL', name: 'bookImage' },
                ].map(({ label, name, type = 'text' }) => (
                  <Form.Group className="mb-3" key={name}>
                    <Form.Label>{label}</Form.Label>
                    <Form.Control
                      type={type}
                      name={name}
                      value={book[name]}
                      onChange={handleChange}
                      placeholder={`Enter ${label.toLowerCase()}`}
                    />
                  </Form.Group>
                ))}

                <Button variant="success" onClick={handleSubmit} className="w-100">
                  Add Book
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container> */}



 <Container className="mt-5">
  <Row className="justify-content-md-center">
    <Col md={8}>
      <Card>
        <Card.Body>
          <Card.Title className="text-center mb-4">Add New Book</Card.Title>
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                name="bookTitle"
                value={book.bookTitle}
                onChange={handleChange}
                placeholder="Enter title"
                required
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Author</Form.Label>
              <Form.Control
                type="text"
                name="bookAuthor"
                value={book.bookAuthor}
                onChange={handleChange}
                placeholder="Enter author"
                required
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Quantity</Form.Label>
              <Form.Control
                type="number"
                name="bookQuantity"
                value={book.bookQuantity}
                onChange={handleChange}
                placeholder="Enter quantity"
                required
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Genre</Form.Label>
              <Form.Control
                type="text"
                name="bookGenre"
                value={book.bookGenre}
                onChange={handleChange}
                placeholder="Enter genre"
                required
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Year of Publication</Form.Label>
              <Form.Control
                type="number"
                name="bookYOP"
                value={book.bookYOP}
                onChange={handleChange}
                placeholder="Enter year of publication"
                required
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Edition</Form.Label>
              <Form.Control
                type="text"
                name="bookEdition"
                value={book.bookEdition}
                onChange={handleChange}
                placeholder="Enter edition"
                required
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Price</Form.Label>
              <Form.Control
                type="number"
                name="bookPrice"
                value={book.bookPrice}
                onChange={handleChange}
                placeholder="Enter price"
                required
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Cover Type</Form.Label>
              <Form.Control
                type="text"
                name="bookCoverType"
                value={book.bookCoverType}
                onChange={handleChange}
                placeholder="Enter cover type"
                required
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Image URL</Form.Label>
              <Form.Control
                type="text"
                name="bookImage"
                value={book.bookImage}
                onChange={handleChange}
                placeholder="Enter image URL"
                required
              />
            </Form.Group>

            <Button variant="success" type="submit" className="w-100">
              Add Book
            </Button>
          </Form>
        </Card.Body>
      </Card>
    </Col>
  </Row>
</Container>




      </>
  );
}

export default AddBook;
