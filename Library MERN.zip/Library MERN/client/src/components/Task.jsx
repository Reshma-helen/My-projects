import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button, Card, CardBody, CardFooter, CardHeader, Form } from 'react-bootstrap';

const Task = () => {
  const [task, setTask] = useState('');
  const [taskList, setTaskList] = useState([]);
  const [editId, setEditId] = useState(null);
  const [editText, setEditText] = useState('');

  // Fetch all tasks on mount
  useEffect(() => {
    axios.get('http://localhost:5000/todos')
      .then(res => setTaskList(res.data))
      .catch(err => console.error(err));
  }, []);

  // Add new task
  const handleAdd = () => {
    if (!task.trim()) return alert('Task should not be empty!');
    axios.post('http://localhost:5000/todos', { text: task, status: 'pending' })
      .then(res => {
        setTaskList([...taskList, res.data]);
        setTask('');
      })
      .catch(err => console.error(err));
  };

  // Delete
  const handleDelete = id => {
    if (!window.confirm('Are you sure you want to delete this task?')) return;
    axios.delete(`http://localhost:5000/todos/${id}`)
      .then(() => {
        setTaskList(taskList.filter(t => t._id !== id));
      })
      .catch(err => console.error(err));
  };

  // Begin edit
  const handleEdit = item => {
    setEditId(item._id);
    setEditText(item.text);
  };
  // Save edited text
  const handleSave = () => {
    axios.put(`http://localhost:5000/todos/${editId}`, { text: editText })
      .then(res => {
        setTaskList(taskList.map(t => t._id === editId ? res.data : t));
        setEditId(null);
        setEditText('');
      })
      .catch(err => console.error(err));
  };

  // Mark Done
  const handleDone = item => {
    axios.put(`http://localhost:5000/todos/${item._id}`, { status: 'done' })
      .then(res => {
        setTaskList(taskList.map(t => t._id === item._id ? res.data : t));
      })
      .catch(err => console.error(err));
  };

  // Postpone
  const handlePostpone = item => {
    axios.put(`http://localhost:5000/todos/${item._id}`, { status: 'postponed' })
      .then(res => {
        setTaskList(taskList.map(t => t._id === item._id ? res.data : t));
      })
      .catch(err => console.error(err));
  };

  // Helper to pick the variant for the main label button
  const labelVariant = status => {
    if (status === 'done') return 'outline-success';
    if (status === 'postponed') return 'outline-warning';
    return 'light';
  };

  return (
    <>
      <div className='container w-75'>
        <Card>
          <CardHeader>
            <h1>My To Do List</h1>
          </CardHeader>
          <CardBody>
            <Form.Control
              placeholder='Enter new task'
              value={task}
              onChange={e => setTask(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleAdd()}
            />
          </CardBody>
          <CardFooter>
            <Button onClick={handleAdd}>Add Task</Button>
          </CardFooter>
        </Card>
      </div>

      <div className='container w-75 mt-3'>
        <h2>Tasks</h2>
        {taskList.map(item => (
          <div className='btn-group container mt-2' key={item._id}>
            {/* Done */}
            <Button variant='success' className='col-1' onClick={() => handleDone(item)}>
              Done <i className="bi bi-check2-circle"></i>
            </Button>

            {/* Task Label or Edit Input */}
            {editId === item._id ? (
              <Form.Control
                className='btn btn-light col-8'
                value={editText}
                onChange={e => setEditText(e.target.value)}
              />
            ) : (
              <Button variant={labelVariant(item.status)} className='col-8'>
                {item.text}
              </Button>
            )}

            {/* Edit / Save */}
            {editId === item._id ? (
              <Button variant='primary' className='col-1' onClick={handleSave}>
                <i className="bi bi-floppy"></i>
              </Button>
            ) : (
              <Button variant='info' className='col-1' onClick={() => handleEdit(item)}>
                <i className="bi bi-pencil"></i>
              </Button>
            )}

            {/* Postpone */}
            <Button variant='warning' className='col-1' onClick={() => handlePostpone(item)}>
              <i className="bi bi-hourglass"></i>
            </Button>

            {/* Delete */}
            <Button variant='danger' className='col-1' onClick={() => handleDelete(item._id)}>
              <i className="bi bi-trash"></i>
            </Button>
          </div>
        ))}
      </div>
    </>
  );
};

export default Task;