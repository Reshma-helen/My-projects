// import { useEffect, useState } from 'react';
// import axios from 'axios';
// import { Table, Container } from 'react-bootstrap';

// function Dashboard() {
//   const [books, setBooks] = useState([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     // Fetch books from backend
//     const fetchBooks = async () => {
//       try {
//         const res = await axios.get('http://localhost:5000/books');
//         if (res.data.success) {
//           setBooks(res.data.books);
//         } else {
//           alert('Failed to fetch books');
//         }
//       } catch (error) {
//         console.error(error);
//         alert('Error fetching books');
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchBooks();
//   }, []);

//   if (loading) return <Container><p>Loading books...</p></Container>;

//   return (
//     <Container className="mt-4">
//       <h2>Book Dashboard</h2>
//       <Table striped bordered hover responsive>
//         <thead>
//           <tr>
//             <th>Title</th>
//             <th>Author</th>
//             <th>Quantity</th>
//             <th>Genre</th>
//             <th>Year of Publication</th>
//             <th>Edition</th>
//             <th>Price</th>
//             <th>Cover Type</th>
//             <th>Image</th>
//           </tr>
//         </thead>
//         <tbody>
//           {books.map((book) => (
//             <tr key={book._id}>
//               <td>{book.bookTitle}</td>
//               <td>{book.bookAuthor}</td>
//               <td>{book.bookQuantity}</td>
//               <td>{book.bookGenre}</td>
//               <td>{book.bookYOP}</td>
//               <td>{book.bookEdition}</td>
//               <td>{book.bookPrice}</td>
//               <td>{book.bookCoverType}</td>
//               <td>
//                 {book.bookImage ? (
//                   <img
//                     src={book.bookImage}
//                     alt={book.bookTitle}
//                     style={{ width: '60px', height: '80px', objectFit: 'cover' }}
//                   />
//                 ) : (
//                   'No image'
//                 )}
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </Table>
//     </Container>
//   );
// }

// export default Dashboard;




import React from 'react';
import {useState,useEffect} from 'react';
import axios from 'axios'
import { Navbar, Container, Nav,Button,Form,Row,Col,Card, } from 'react-bootstrap';
import {useNavigate} from 'react-router-dom'

const AppNavbar = () => {


const [books, setBooks] = useState([]);

  useEffect(() => {
    // Fetch books from backend
    axios.get('http://localhost:5000/books')
      .then((response) => {
        setBooks(response.data.books);
      })
      .catch((error) => {
        console.error('Error fetching books:', error);
      });
  }, []);





   const navigate=useNavigate()
   const handleLogout = async() => {
     
      // alert('You have been logged out.');
      // navigate('/login');
  
       try {
        await axios.post('http://localhost:5000/logout'); // optional
      } catch (error) {
        console.error('Logout error:', error);
      }
  
      localStorage.removeItem('isLoggedIn'); // remove flag
      navigate('/login'); // redirect
    };


return(
    <>
  <Navbar bg="dark" variant="dark" expand="lg" sticky="top">
    <Container>
      <Navbar.Brand href="#">Book Management</Navbar.Brand>
      <Navbar.Toggle aria-controls="nav" />
      <Navbar.Collapse id="nav">
        <Nav className="ms-auto">
          <Nav.Link href="#home">Home</Nav.Link>
           <Nav.Link href="/addbook">Add Books</Nav.Link>
          <Nav.Link href="/booklist">View Book List</Nav.Link>
          <Nav.Link href="#contact">Contact</Nav.Link>
          <Nav.Link onClick={handleLogout} style={{ cursor: 'pointer' }}> Logout </Nav.Link>
        </Nav>
      </Navbar.Collapse>
    </Container>
  </Navbar>


{/* top section */}

  <div id="home" style={{ backgroundColor: '#0b2a61' }} className="text-white text-center py-5">
    <Container>
      <h1 className="display-4">Manage Your Library with Ease</h1>
      <p className="lead">Organize, track, and access all your books in one convenient place.</p>
      <Button variant="light" size="lg">Get Started</Button>
    </Container>
  </div>

{/* Books  */}

 <div id="books" className="py-5 bg-light">
      <Container>
        <h2 className="text-center mb-4">Available Books</h2>
        <Row>
          {/* {books.map((book, index) => ( */}
          {books.slice(0, 3).map((book, index) => (

            <Col md={4} className="mb-4" key={index}>
              <Card className="h-100 shadow-sm">
                <Card.Img variant="top" src={book.bookImage} style={{ height: '200px' ,objectFit: 'cover' }} />
                <Card.Body>
                  <Card.Title>{book.bookTitle}</Card.Title>
                  <Card.Text>
                    <strong>Author:</strong> {book.bookAuthor}<br />
                    <strong>Genre:</strong> {book.bookGenre}<br />
                    <strong>Price:</strong> ₹{book.bookPrice}<br />
                    <strong>Edition:</strong> {book.bookEdition}<br />
                    <strong>YOP:</strong> {book.bookYOP}
                  </Card.Text>
                  {/* <Button variant="primary">View Details</Button> */}
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </div>

{/* Contact section */}


 <div id="contact" className="py-5" style={{ backgroundColor: '#0b2a61' }}>
    <Container>
      <h2 className="text-center mb-4 text-light">Contact Us</h2>
      <Form style={{ maxWidth: '600px', margin: '0 auto' }}>
        <Form.Group className="mb-3">
          <Form.Label className="text-light">Name</Form.Label>
          <Form.Control type="text" placeholder="Your Name" />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label className="text-light">Email</Form.Label>
          <Form.Control type="email" placeholder="Your Email" />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label className="text-light">Message</Form.Label>
          <Form.Control as="textarea" rows={4} placeholder="Your Message" />
        </Form.Group>
        <div className="text-center">
            <Button variant="primary" type="submit">Send Message</Button>
        </div>     
      </Form>
    </Container>
  </div>
  

{/* Footer section */}


<footer className="bg-dark text-white text-center py-3">
    <Container>
      <p className="mb-0">&copy; {new Date().getFullYear()} Book Management. All rights reserved.</p>
    </Container>
  </footer>


</>
)
};

export default AppNavbar;

