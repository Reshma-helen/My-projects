
//-------------------Normal App Route code---------------------------------------------

// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import Register from './components/Register';
// import Login from './components/Login';
// import Home from './components/Home';

// function App() {
//   return (
//     <Router>
//       <Routes>
//         <Route path="/" element={<Register />} />
//         <Route path="/login" element={<Login />} />
//         <Route path="/home" element={<Home />} />
//       </Routes>
//     </Router>
//   );
// }

// export default App;


//---------------------------Private Route added code------------------------------------------

// App.jsx
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Register from './components/Register';
import Login from './components/Login';

import PrivateRoute from './components/PrivateRoute';


import AddBook from './components/AddBook';
import Dashboard from './components/Dashboard'
import BookList from './components/BookList'
import Task from './components/Task'

import Cart from './components/Cart';



function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Register />} />
        <Route path="/login" element={<Login />} />

        
        <Route path="/cart" element={<Cart />} />

        <Route path="/dashboard" element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        />

        <Route path="/addbook" element={ <PrivateRoute>
              <AddBook />
            </PrivateRoute> } />

        {/* <Route path="/dashboard" element={ <Dashboard /> } /> */}

        <Route path="/booklist" element={ <PrivateRoute>
              <BookList />
            </PrivateRoute>} />

          <Route path="/todo" element={<Task/>}/>


      </Routes>
    </Router>
  );
}

export default App;
