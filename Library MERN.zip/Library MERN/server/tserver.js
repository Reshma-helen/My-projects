const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect('mongodb://127.0.0.1:27017/todolist', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log("MongoDB connected"))
  .catch(err => console.error(err));

// Todo Schema
const todoSchema = new mongoose.Schema({
  text: String,
  status: {
    type: String,
    enum: ['pending', 'done', 'postponed'],
    default: 'pending',
  }
});

const Todo = mongoose.model('Todo', todoSchema);

// Routes

// Get all todos
app.get('/todos', async (req, res) => {
  const todos = await Todo.find();
  res.json(todos);
});

// Add new todo
app.post('/todos', async (req, res) => {
  const { text } = req.body;
  const todo = new Todo({ text });
  await todo.save();
  res.json(todo);
});

// Update todo (text or status)
app.put('/todos/:id', async (req, res) => {
  const { text, status } = req.body;
  const update = {};
  if (text !== undefined) update.text = text;
  if (status !== undefined) update.status = status;

  const updated = await Todo.findByIdAndUpdate(req.params.id, update, { new: true });
  res.json(updated);
});

// Delete todo
app.delete('/todos/:id', async (req, res) => {
  await Todo.findByIdAndDelete(req.params.id);
  res.sendStatus(204);
});

// Start server
app.listen(5000, () => {
  console.log("Server running on http://localhost:5000");
});