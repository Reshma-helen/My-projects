const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
  bookTitle: String,
  bookAuthor: String,
  bookQuantity: Number,
  bookGenre: String,
  bookYOP: Number,
  bookEdition: String,
  bookPrice: Number,
  bookCoverType: String,
  bookImage: String, // URL or base64 string
});

module.exports = mongoose.model('Book', bookSchema);
