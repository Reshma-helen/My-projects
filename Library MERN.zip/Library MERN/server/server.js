const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const User = require('./models/User');

const app = express();
app.use(cors());
app.use(express.json());
const bcrypt = require('bcrypt'); // <-- import bcrypt

mongoose.connect('mongodb://127.0.0.1:27017/simpleAuth');


//normal code

// app.post('/register', async (req, res) => {
//   const { firstName, lastName, email, password } = req.body;

//   const userExists = await User.findOne({ email });
//   if (userExists) {
//     return res.json({ success: false, message: 'Email already registered' });
//   }

//   const newUser = new User({ firstName, lastName, email, password });
//   await newUser.save();
//   res.json({ success: true, message: 'Registration successful' });
// });


//using bcrypt for passowrd security hashing

app.post('/register', async (req, res) => {
  const { firstName, lastName, email, password } = req.body;

  const existingUser = await User.findOne({ email });
  if (existingUser) {
    return res.json({ message: 'User already exists' });
  }

  // 🔐 Hash the password
  const hashedPassword = await bcrypt.hash(password, 10);

  const newUser = new User({
    firstName,
    lastName,
    email,
    password: hashedPassword
  });

  await newUser.save();

  res.json({ message: 'User registered successfully' });
});


// normal code for login

// app.post('/login', async (req, res) => {
//   const { email, password } = req.body;

//   const user = await User.findOne({ email });
//   if (!user) return res.json({ success: false, message: 'User not found' });

//   if (user.password === password) {
//     return res.json({ success: true, message: 'Login successful' });
//   } else {
//     return res.json({ success: false, message: 'Incorrect password' });
//   }
// });


// using bcrpyt

app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });
  if (!user) {
    return res.json({ success: false, message: 'User not found' });
  }

  //  Compare entered password with hashed one
  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.json({ success: false, message: 'Incorrect password' });
  }

  res.json({ success: true, message: 'Login successful' });
});


app.listen(5000, () => {
  console.log('Server is running on port 5000');
});


//-------------------TO ADD A BOOK TO THE BACKEND ---------------------------------------------------------------

const Book = require('./models/Book');

app.post('/addbook', async (req, res) => {
  try {
    const newBook = new Book(req.body);
    await newBook.save();
    res.json({ success: true, message: 'Book added successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Failed to add book' });
  }
});


//------------to view the book in dashboard page-------------------------------------------



app.get('/books', async (req, res) => {
  try {
    const books = await Book.find();  // Fetch all books from MongoDB
    res.json({ success: true, books });
  } catch (error) {
    console.error('Error fetching books:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch books' });
  }
});

//----------------to update already existing book --------------------------------------------

app.put('/books/:id', async (req, res) => {
  try {
    const updatedBook = await Book.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json({ success: true, message: 'Book updated successfully', book: updatedBook });
  } catch (error) {
    console.error('Error updating book:', error);
    res.status(500).json({ success: false, message: 'Failed to update book' });
  }
});


//------------------------ to Delete a book ------------------------------------------------------



app.delete('/books/:id', async (req, res) => {
  try {
    await Book.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Book deleted successfully'});
  } catch (error) {
    console.error('Error deleting book:', error);
    res.status(500).json({ success: false, message: 'Failed to delete book'});
  }
});


