import cv2

# Create an object to read from camera
video = cv2.VideoCapture(0)

# Check if camera is opened previously or not
if not video.isOpened():
    print("Error reading video file")

# Set resolutions
frame_width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
size = (frame_width, frame_height)

# Create VideoWriter object to save the video as MP4
result = cv2.VideoWriter('filename.mp4',
                         cv2.VideoWriter_fourcc(*'H264'),
                         10, size)

while True:
    ret, frame = video.read()

    if ret:
        # Write the frame into the MP4 file
        result.write(frame)

        # Display the frame
        cv2.imshow('Frame', frame)

        # Press 's' on keyboard to stop the process
        if cv2.waitKey(1) & 0xFF == ord('s'):
            break
    else:
        break

# Release the video capture and video write objects
video.release()
result.release()

# Close all frames
cv2.destroyAllWindows()

print("The video was successfully saved as MP4")
