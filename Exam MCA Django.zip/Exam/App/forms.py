from django import forms
from .models import *



class BaseModelForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(BaseModelForm, self).__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.widget.attrs['class'] = 'form-control'
            if isinstance(field.widget, forms.Select):
                field.widget.attrs['class'] = 'form-select'
                
        for field_name, field in self.fields.items():
            cleaned_field_name = field_name.replace('_', ' ')
            # field.widget.attrs['placeholder'] = f'Enter {cleaned_field_name.capitalize()}'

class UploadQuestionsForm(BaseModelForm):
    class Meta:
        model = UploadQuestions
        exclude = ['tr']
        
        
class QuestionsForm(BaseModelForm):
    class Meta:
        model = Questions
        exclude = ['uq']
    