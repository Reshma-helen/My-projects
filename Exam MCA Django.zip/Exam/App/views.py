import time
from django.http import JsonResponse, StreamingHttpResponse
from django.shortcuts import render,redirect
from . models import *
from django.contrib.auth.models import User,auth
import cv2
from django.contrib.auth import logout
from django.contrib.auth.hashers import check_password
from django.views import View
from .forms import UploadQuestionsForm,QuestionsForm
from django.urls import reverse
from django.shortcuts import redirect
from django.views.decorators.http import require_GET
import face_recognition
from django.urls import reverse
from moviepy.editor import VideoFileClip




# Create your views here.
sss = ''
aaa = ''
def index(request):
    return render(request,'student/index.html')

def stud_index(request):
    use=Student.objects.get(user=request.user)
    context = {
        'use':use
    }
    return render(request,'student/stud_index.html',context)

def stud_login(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        if Student.objects.filter(user__username=username).exists():
            stud=Student.objects.get(user__username=username)
            print(stud.is_approved)
            if stud.is_approved=='yes':
                u=auth.authenticate(username=username,password=password)
                if u is not None:
                    auth.login(request,u)
                    return redirect(stud_index)
                else:
                    print("hello")
                    context ={
                        'key':'Invalid user'
                    }
                    return render(request,'student/stud_login.html',context)
            elif stud.is_approved=='no':
                context ={
                    'key':'User is rejected'
                }
                return render(request,'student/stud_login.html',context)
            else:
                context ={
                    'key':'Waiting'
                }
                return render(request,'student/stud_login.html',context)
        else:
            print('hai')
            context ={
                'key':'Invalid user'
            }
            return render(request,'student/stud_login.html',context)

    return render(request,'student/stud_login.html')

def stud_register(request):
    dept = Department.objects.all()
    if request.method=='POST':
        f_name=request.POST['f_name']
        roll_num=request.POST['roll_num']
        dept=request.POST['dept']
        print(dept)
        batch=request.POST['batch']
        sem=request.POST['sem']
        email=request.POST['email']
        p_no=request.POST['p_no']
        ad_no=request.POST['ad_no']
        uname=request.POST['uname']
        pas=request.POST['pas']
        cpas=request.POST['cpas']
        if pas==cpas:
            if Student.objects.filter(user__username=uname).exists() or User.objects.filter(username=uname).exists():
                context ={
                    'key':'Username already exists'
                }
                print(0)
                return render(request,'student/stud_register.html',context)
            elif Student.objects.filter(user__email=email).exists() or User.objects.filter(email=email).exists():
                context ={
                    'key2':'Email already exists'
                }
                print(1)
                return render(request,'student/stud_register.html',context)
            elif Student.objects.filter(roll_number=roll_num).exists():
                context={
                    'keyr':'Roll Number already exists'
                }
                print(3)
                return render(request,'student/stud_register.html',context)
            elif Student.objects.filter(admission_no=ad_no).exists():
                context={
                    'keya':'Admission Number already exists'
                }
                print(4)
                return render(request,'student/stud_register.html',context)
            else:
                User.objects.create_user(username=uname,email=email,password=pas).save()
                user=User.objects.get(username=uname)
                dep = Department.objects.get(dept=dept)
                Student(user=user,name=f_name,roll_number=roll_num,dept=dep,sem=sem,batch=batch,phone=p_no,admission_no=ad_no).save()
                context ={
                    'key1':'Successfully registered '
                }
                print(2)
                return render(request,'student/stud_login.html',context)
                # return redirect(stud_reg_image)

        else:
            context ={
                'key3':'password does not match',
                'dept':dept
            }
            print(len(dept))
            return render(request,'student/stud_register.html',context)
    context ={
        'dept':dept
    }
    print(len(dept))
    return render(request,'student/stud_register.html',context)

def stud_reg_image(request):
    u=Student.objects.get(user=request.user)
    context = {'cam': 'LIVE','u':u}
    return render(request,'student/reg_image.html',context)


import cv2
def live_feed(request):
    
    webcam = cv2.VideoCapture(0)
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    def video_stream():
        while True:
            # Read the frame
            ret, img = webcam.read()
            # Convert to grayscale
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            
            # Detect the faces
            faces = face_cascade.detectMultiScale(gray, 1.1,  5, minSize=(40, 40))
            
            for (x, y, w, h) in faces:
                cv2.putText(img, "face detected",(70,70), cv2.FONT_HERSHEY_PLAIN, 3,(0,255,0),2)
                print('true1')
            _, frame = webcam.read()
            _, buffer = cv2.imencode('.jpg', img)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')

    response = StreamingHttpResponse(video_stream(), content_type='multipart/x-mixed-replace;boundary=frame')
    response['Cache-Control'] = 'no-store, no-cache, must-revalidate, private, max-age=0'
    return response

import cv2
from django.core.files.base import ContentFile
from io import BytesIO
from PIL import Image
from django.core.files.uploadedfile import InMemoryUploadedFile
import uuid
import os

def cap(request):
    # Capture image from webcam
    # user=Student.objects.get(user=u)
    
    print(request.user)
    u=Student.objects.get(user=request.user)
    
    webcam = cv2.VideoCapture(0)
    check, frame = webcam.read()
    name=str(u.admission_no)
    n=name+'.jpeg'
    # Convert the OpenCV image (BGR) to PIL format (RGB)
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    pil_image = Image.fromarray(frame_rgb)

    # Generate a unique image name using a combination of timestamp and random characters
    unique_image_name = f'{uuid.uuid4().hex[:8]}_{int(time.time())}.jpeg'

    # Save the image to BytesIO buffer
    image_buffer = BytesIO()
    pil_image.save(image_buffer, format='JPEG')
    image_data = image_buffer.getvalue()
    unique_image_name=n
    # Save the image data to the Student instance with the unique image name
    
    u.image.save(unique_image_name, InMemoryUploadedFile(
        ContentFile(image_data),
        None,
        unique_image_name,
        'image/jpeg',
        len(image_data),
        None
    ))

    # Close the webcam
    webcam.release()
    ur=Student.objects.get(user=request.user)
    context = {'cam': 'LIVE','u':ur,'msg9':'Successfully Uploaded the Image'}
    return render(request,'student/reg_image.html',context)
    # return redirect(stud_index)

def s_changepassword(request):
    return render(request,'student/stud_changepassword.html')


def s_changepassword(request):
    use=User.objects.get(username=request.user)
    if request.method=='POST':
        currentpassword=request.POST['current_password']
        newpasssword=request.POST['new_password']
        confirmpasssword=request.POST['confirm_password']
        if newpasssword == confirmpasssword:
            print(use.password)
            checkpassword=check_password(currentpassword,use.password)
            print(checkpassword)
            if checkpassword==True:
                use.set_password(newpasssword)
                use.save()
                u=auth.authenticate(username=use.username,password=newpasssword)
                logout(request)
                print(u)
                auth.login(request,u)
                context = {
                    'k':'Password changed successfully'
                }
                return render(request,"student/stud_changepassword.html",context)
            else:
                context = {
                    'k1':'Current password is not correct'
                }
            return render(request,"student/stud_changepassword.html",context)
        else:
            context = {
                'k1':'Password does not match'
            }
            return render(request,"student/stud_changepassword.html",context)
    return render(request,"student/stud_changepassword.html")

def stud_profile(request):
    use=Student.objects.get(user=request.user)
    context = {
        'use':use
    }
    return render(request,'student/stud_profile.html',context)

def stud_update_profile(request):
    use=Student.objects.get(user=request.user)
    context = {
        'use':use
    }
    user=User.objects.get(username=request.user)
    if request.method=='POST':
        use.name=request.POST['fullname']
        user.username=request.POST['username']
        use.sem=request.POST['sem']
        use.batch=request.POST['batch']
        use.roll_number=request.POST['rollno']
        use.admission_no=request.POST['adm_no']
        use.phone=request.POST['p_no']
        user.email=request.POST['email']
        user.save()
        use.save()
        return redirect(stud_profile)
    return render(request,"student/stud_updateprofile.html",context)

def log_out(request):
    logout(request)
    return redirect(index)



def t_login(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        if Teacher.objects.filter(user__username=username).exists():
            st=Teacher.objects.get(user__username=username)
            print(st.is_approved)
            if st.is_approved=='yes':
                u=auth.authenticate(username=username,password=password)
                if u is not None:
                    auth.login(request,u)
                    return redirect(t_index)
                else:
                    context ={
                        'key':'Invalid user'
                    }
                    return render(request,'teacher/teacher_login.html',context)
            elif st.is_approved=='no':
                context ={
                    'key':'User is rejected'
                }
                return render(request,'teacher/teacher_login.html',context)
            else:
                context ={
                    'key':'Waiting'
                }
                return render(request,'teacher/teacher_login.html',context)
        else:
            context ={
                'key':'Invalid user'
            }
            return render(request,'teacher/teacher_login.html',context)

    return render(request,'teacher/teacher_login.html')


def t_reg(request):
    d = Department.objects.all()
    if request.method=='POST':
        f_name=request.POST['f_name']
        uname=request.POST['uname']
        t_id=request.POST['t_id']
        dept=request.POST['dept']
        email=request.POST['email']
        p_no=request.POST['p_no']
        pas=request.POST['pas']
        cpas=request.POST['cpas']
        if pas==cpas:
            if Student.objects.filter(user__username=uname).exists() or User.objects.filter(username=uname).exists():
                context ={
                    'key':'Username already exists',
                    'dept':d
                }
                print(0)
                return render(request,'teacher/teacher_registration.html',context)
            elif Teacher.objects.filter(user__email=email).exists() or User.objects.filter(email=email).exists():
                context ={
                    'key2':'Email already exists',
                    'dept':d
                }
                print(1)
                return render(request,'teacher/teacher_registration.html',context)
            elif Teacher.objects.filter(t_id=t_id).exists():
                context ={
                    'keyi':'ID already exists',
                    'dept':d
                }
                print(1)
                return render(request,'teacher/teacher_registration.html',context)
            else:
                User.objects.create_user(username=uname,email=email,password=pas).save()
                user=User.objects.get(username=uname)
                dep = Department.objects.get(dept=dept)
                Teacher(user=user,name=f_name,t_id=t_id,dept=dep,phone=p_no).save()
                context ={
                    'key1':'Successfully registered '
                }
                print(2)
                return render(request,'teacher/teacher_login.html',context)
                # return redirect(stud_reg_image)

        else:
            context ={
                'key3':'password does not match',
                'dept':d
            }
            print(3)
            return render(request,'teacher/teacher_registration.html',context)
    context = {
        'dept':d
    }
    return render(request,'teacher/teacher_registration.html',context)


def t_index(request):
    t=Teacher.objects.get(user=request.user)
    context = {
        't':t
    }   
    return render(request,'teacher/teacher_index.html',context)

def t_profile(request):
    t=Teacher.objects.get(user=request.user)
    context = {
        't':t
    }
    return render(request,'teacher/teacher_profileview.html',context)

def t_update_profile(request):
    t1=Teacher.objects.get(user=request.user)
    context = {
        't1':t1
    }
    user=User.objects.get(username=request.user)
    if request.method=='POST':
        t1.name=request.POST['fullname']
        user.username=request.POST['username']
        t1.phone=request.POST['p_no']
        user.email=request.POST['email']
        user.save()
        t1.save()
        return redirect(t_profile)
    return render(request,"teacher/teacher_update.html",context)

def t_changepassword(request):
    t2=User.objects.get(username=request.user)
    if request.method=='POST':
        currentpassword=request.POST['current_password']
        newpasssword=request.POST['new_password']
        confirmpasssword=request.POST['confirm_password']
        if newpasssword == confirmpasssword:
            print(t2.password)
            checkpassword=check_password(currentpassword,t2.password)
            print(checkpassword)
            if checkpassword==True:
                t2.set_password(newpasssword)
                t2.save()
                u=auth.authenticate(username=t2.username,password=newpasssword)
                logout(request)
                print(u)
                auth.login(request,u)
                context = {
                    'k':'Password changed successfully'
                }
                return render(request,"teacher/teacher_changepassword.html",context)
            else:
                context = {
                    'k1':'Current password is not correct'
                }
            return render(request,"teacher/teacher_changepassword.html",context)
        else:
            context = {
                'k1':'Password does not match'
            }
            return render(request,"teacher/teacher_changepassword.html",context)
    return render(request,"teacher/teacher_changepassword.html")

def t_logout(request):
    logout(request)
    return redirect(index)

def tr_view_stud_result(request,pk):
    stud = Student.objects.get(id=pk)
    res1 = Result.objects.filter(stud=stud,assessment=1,uq__sem=stud.sem)
    res2 = Result.objects.filter(stud=stud,assessment=2,uq__sem=stud.sem)
    context = {
        'res1':res1,
        'res2':res2
    }
    
    return render(request,"teacher/teacher_view_result.html",context)
def sel_stud(request):
    dept=Department.objects.all()
    context={
        'dept':dept
    }
    if request.method=="POST":
        dep=request.POST['dept']
        sem=request.POST['sem']
        if Student.objects.filter(dept=dep,sem=sem).exists():
            stud=Student.objects.filter(dept=dep,sem=sem)
            context={
                'stud':stud
            }
            return render(request,'teacher/studentlistview.html',context)
        else:
            context={
                'dept':dept,
                'msg':'No students yet registered in the semester in the following department'
            }
            return render(request,'teacher/studentlist.html',context)
        
    return render(request,'teacher/studentlist.html',context)



class UploadQuestionsView(View):
    template = 'teacher/upload_questions.html'
    def get(self, request):
        form = UploadQuestionsForm()
        return render(request, 'teacher/upload_questions.html', {'form': form})
    
    def post(self, request):
        form = UploadQuestionsForm(request.POST)
        if form.is_valid():
            tr = Teacher.objects.get(user=request.user)
            form.instance.tr = tr

            # Check if a similar question already exists
            existing_question = UploadQuestions.objects.filter(
                tr=tr,
                dept=form.cleaned_data['dept'],
                sub=form.cleaned_data['sub'],
                module=form.cleaned_data['module'],
                sem=form.cleaned_data['sem']
            ).first()

            if existing_question:
                existing_question = UploadQuestions.objects.get(
                    tr=tr,
                    dept=form.cleaned_data['dept'],
                    sub=form.cleaned_data['sub'],
                    module=form.cleaned_data['module'],
                    sem=form.cleaned_data['sem']
                )
                a=existing_question.id
                print('hai')
                return redirect(reverse('add_questions', args=[a]))

            form.save()
            a = form.instance.id
            context = {
                'form': form,
                'success_message': 'Successfully added'
            }
            return redirect(reverse('add_questions', args=[a]))
        return render(request, self.template, {'form': form})
    
class ViewQuestions(View):
    template = 'teacher/view_questions.html'
    def get(self, request):
        tr=Teacher.objects.get(user=request.user)
        ques = UploadQuestions.objects.filter(tr=tr)
        context = {
            'data':ques
        }
        return render(request, 'teacher/view_questions.html',context)
    
    
def delete_module(request,pk):
    print('aaaaa')
    val = UploadQuestions.objects.get(id=pk)
    val.delete()
    print(0)
    print('dddd')
    return redirect('view_questions')

    
class ViewSubQuestions(View):
    def get(self, request,pk):
        up_question=UploadQuestions.objects.get(id=pk)
        if Questions.objects.filter(uq=up_question).exists():
            
            qus=Questions.objects.filter(uq=up_question)
            print(qus)
            context = {
                'data':qus,
                'pk':pk
            }
            return render(request, 'teacher/sub_questionview.html',context)    
        else:
            context={
                'msg':'No Questions uploaded for this Module'
                
            }
            return render(request, 'teacher/sub_questionview.html',context)
    
class AddQuestionsView(View):
    template = 'teacher/add_questions.html'
    def get(self, request,pk):
        form = QuestionsForm()
        return render(request, self.template, {'form': form})
    
    def post(self, request,pk):
        form = QuestionsForm(request.POST)
        if form.is_valid():
            form.save(commit=False)
            q = UploadQuestions.objects.get(id=pk)
            form.instance.uq = q

            form.save()
            # a = form.instance.id
            context = {
                'form':form,
                'success_message':'sucessfully added',
                'pk':pk
            }
            return render(request, self.template,context )
        return render(request, self.template, {'form': form})

def tr_edit_qus(request, pk,ak):
    question = Questions.objects.get(pk=pk)
    if request.method == 'POST':
        form = QuestionsForm(request.POST, instance=question)
        if form.is_valid():
            form.save()
            url = reverse('view_sub_questions', args=[ak])
    
            return redirect(url)
            return redirect(t_index)  # Redirect to some success URL
    else:
        form = QuestionsForm(instance=question)
    
    return render(request, 'teacher/add_questions.html', {'form': form,'edit':'edit'})  
    
def teacher_viewquestion(request):
    return render(request,'teacher/teacher_view_questions.html')

def stud_exam(request):
    user = Student.objects.get(user=request.user)
    sub = Subjects.objects.filter(department__dept=user.dept,semester=user.sem)
    print(sub)
    
    context = {
        'sub':sub
    }
    return render(request,'student/stud_exam.html',context)

def start_verification(request,pk,a):
    print(pk)
    user=Student.objects.get(user=request.user)
    sub = Subjects.objects.get(id=pk)
    print(a)
    print(type(a))
    
    if a == 1:
        if UploadQuestions.objects.filter(dept=user.dept,sub=sub,module='3').exists():
            aa=UploadQuestions.objects.get(dept=user.dept,sub=sub,module='3')
            if Result.objects.filter(stud=user,uq__sub=sub,uq=aa).exists():
                print('my reshma')
                context = {
                    'msgg':"Already Attended"
                }
                return render(request,'student/start_verification.html',context)
            else:
                print('my ashik')
                context = {'cam': 'LIVE','u':user,'sub':sub.id,'a':a}
                return render(request,'student/start_verification.html',context)
        else :
            context = {'msg':'Question paper is not uploaded for this exam'}
            return render(request,'student/no_exam.html',context)
    elif a == 2:
        if UploadQuestions.objects.filter(dept=user.dept,sub=sub,module='6').exists():
            aa=UploadQuestions.objects.get(dept=user.dept,sub=sub,module='6')
            if Result.objects.filter(stud=user,uq__sub=sub,uq=aa).exists():
                context = {
                    'msgg':"Already Attended"
                }
                return render(request,'student/start_verification.html',context)
            else:
                context = {'cam': 'LIVE','u':user,'sub':sub.id,'a':a}
                return render(request,'student/start_verification.html',context)
        else :
            context = {'msg':'Question paper is not uploaded for this exam'}
            return render(request,'student/no_exam.html',context)
    # return render(request,'student/start_verification.html',context)

def cap1(request, pk, a):
    sub = Subjects.objects.get(id=pk)
    print(request.user)
    u = Student.objects.get(user=request.user)

    webcam = cv2.VideoCapture(0)
    check, frame = webcam.read()
    name = str(u.roll_number)
    n = name + '.jpeg'
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    pil_image = Image.fromarray(frame_rgb)

    unique_image_name = f'{uuid.uuid4().hex[:8]}_{int(time.time())}.jpeg'

    image_path = f'./verificationimage/{n}'
    pil_image.save(image_path)

    print('hai')
    print('hai')
    cap_pic = face_recognition.load_image_file(u.image)
    print('hai')
    print('hai')
    print('hai')
    print('hai')
    print('hai')
    print('hai')
    print('hai')

    print(u.image)

    cap_pic_encoding = face_recognition.face_encodings(cap_pic)[0]

    print(image_path)
    id_pic = face_recognition.load_image_file(image_path)

    try:
        id_pic_encoding = face_recognition.face_encodings(id_pic)[0]

        results = face_recognition.compare_faces([cap_pic_encoding], id_pic_encoding)

        if results[0] == True:
            print(results)
            print("verification successful")
            webcam.release()
            user = Student.objects.get(user=request.user)
            sub = Subjects.objects.get(id=pk)
            context = {'cam': 'LIVE', 'u': user, 'sub': sub.id, 'msg1': a, 'a': a}
            return render(request, 'student/start_verification.html', context)
        else:
            print(results)
            print('bla bla')
            print("face not recognized")
            webcam.release()

            user = Student.objects.get(user=request.user)
            sub = Subjects.objects.get(id=pk)
            context = {'cam': 'LIVE', 'u': user, 'sub': sub.id, 'msg': 'not verified please try again', 'a': a}
            return render(request, 'student/start_verification.html', context)

    except IndexError:
        print("IndexError: The image is not clear")
        webcam.release()
        try:
            user = Student.objects.get(user=request.user)
            sub = Subjects.objects.get(id=pk)
            context = {'cam': 'LIVE', 'u': user, 'sub': sub.id, 'msg7': 'image is not clear', 'a': a}
            return render(request, 'student/start_verification.html', context)
        except:
            return redirect(stud_exam)

def start_exam1(request,pk,a):
    
    import cv2
    import numpy as np
    import dlib
    global ques
    global sss
    global aaa
    global d
    
    user = Student.objects.get(user=request.user)
    sub = Subjects.objects.get(id=pk)
    
    sss =sub.sub_name
    aaa=1
    
    ques1 = Questions.objects.filter(uq__dept=user.dept,uq__sem=user.sem,uq__sub=sub,uq__module='1')
    ques2 = Questions.objects.filter(uq__dept=user.dept,uq__sem=user.sem,uq__sub=sub,uq__module='2')
    ques3 = Questions.objects.filter(uq__dept=user.dept,uq__sem=user.sem,uq__sub=sub,uq__module='3')
    
    print(len(ques1))
    c1=[]
    c2=[]
    c3=[]
    
    for i in ques1:
        c1.append(i.id)
    for i in ques2:
        c2.append(i.id)
    for i in ques3:
        c3.append(i.id)
    
    print(c1)
    q1=[]
    q2=[]
    q3=[]
    
    while len(q1)<4:
        import random as r
        rd=r.choice(c1)
        if rd not in q1:
            q1.append(rd)
    while len(q2)<4:
        import random as r
        rd=r.choice(c2)
        print(rd)
        if rd not in q2:
            q2.append(rd)
    while len(q3)<2:
        import random as r
        rd=r.choice(c3)
        if rd not in q3:
            q3.append(rd)
    print(q1)
    print(q2)
    print(q3)
    d1=[]
    d2=[]
    d3=[]
    for i in q1:
        global ques
        ques=Questions.objects.get(id=i)
        d1.append(ques)
    for i in q2:
        ques=Questions.objects.get(id=i)
        d2.append(ques)
    for i in q3:
        ques=Questions.objects.get(id=i)
        d3.append(ques)
    d=d1+d2+d3
    print(d)
   


    context = {
        'ques':d, 
        'cam': 'LIVE',
        'a':a
    }
    
    context = {
        'ques':d, 
        'cam': 'LIVE',
        'a':a
    }
    return render(request,'student/start_exam.html', context)
    
    
    
def start_exam2_post(request):
    user = Student.objects.get(user=request.user)

    if request.method=='POST':
        print('kjhajhsdjhagshdfahjsgdjhasdhgajhgsdhjashjdfajhdjafj')
        print(main_count)
        ans1=request.POST.get('ans1')
        ans2=request.POST.get('ans2')
        ans3=request.POST.get('ans3')
        ans4=request.POST.get('ans4')
        ans5=request.POST.get('ans5')
        ans6=request.POST.get('ans6')
        ans7=request.POST.get('ans7')
        ans8=request.POST.get('ans8')
        ans9=request.POST.get('ans9')
        ans10=request.POST.get('ans10')
        print(ans2)
        print('ans2')
        if ans1==d[0].correct_ans:
            m1=1
        else:
            m1=0
        if ans2==d[1].correct_ans:
            m2=1
        else:
            m2=0
        if ans3==d[2].correct_ans:
            m3=1
        else:
            m3=0
        if ans4==d[3].correct_ans:
            m4=1
        else:
            m4=0
        if ans5==d[4].correct_ans:
            m5=1
        else:
            m5=0
        if ans6==d[5].correct_ans:
            m6=1
        else:
            m6=0
        if ans7==d[6].correct_ans:
            m7=1
        else:
            m7=0
        if ans8==d[7].correct_ans:
            m8=1
        else:
            m8=0
        if ans9==d[8].correct_ans:
            m9=1
        else:
            m9=0
        if ans10==d[9].correct_ans:
            m10=1
        else:
            m10=0
        
        mark=m1+m2+m3+m4+m5+m6+m7+m8+m9+m10
        print(mark)
        print('mark')
        if main_count >= 10 or f_count >= 2:
            m=True
            if main_count >= 10:
                mc = True
            else:
                mc=False
            if f_count >=2:
                fc = True
            else:
                fc = False
        else:
            m=False
            mc=False
            fc = False  
        print(mc,fc,m)
        if Result.objects.filter(stud=user,uq=ques.uq,assessment=2).exists():
            context={
                'exam':"Exam already attended,You can't attend the exam again.If any query please contact administration."
            }
            return render(request,'student/start_exam.html', context)
        
        Result(stud=user,uq=ques.uq,total_mark=mark,malpractice=m,multiple_face=fc,head_movement=mc,assessment=2,video=output_video_path).save()
        cv2.destroyAllWindows()
        context = {
            'msg':'SUCCESSFULLY SUBMITTED',
            'ques':d,
            'ques':d,
            'ans1':ans1,
            'ans2':ans2,
            'ans3':ans3,
            'ans4':ans4,
            'ans5':ans5,
            'ans6':ans6,
            'ans7':ans7,
            'ans8':ans8,
            'ans9':ans9,
            'ans10':ans10,
            'm1':m1,
            'm2':m2,
            'm3':m3,
            'm4':m4,
            'm5':m5,
            'm6':m6,
            'm7':m7,
            'm8':m8,
            'm9':m9,
            'm10':m10,
            'mark':mark
        }
        return render(request,'student/key.html',context)
    
    
def start_exam2(request,pk,a):
    
    import cv2
    import numpy as np
    import dlib
    global ques
    global sss
    global aaa
    global d
    print("virat")
    user = Student.objects.get(user=request.user)
    sub = Subjects.objects.get(id=pk)
    sss =sub.sub_name
    aaa=2
    ques1 = Questions.objects.filter(uq__dept=user.dept,uq__sem=user.sem,uq__sub=sub,uq__module='4')
    ques2 = Questions.objects.filter(uq__dept=user.dept,uq__sem=user.sem,uq__sub=sub,uq__module='5')
    ques3 = Questions.objects.filter(uq__dept=user.dept,uq__sem=user.sem,uq__sub=sub,uq__module='6')

    print(len(ques1))
    c1=[]
    c2=[]
    c3=[]
    
    for i in ques1:
        c1.append(i.id)
    for i in ques2:
        c2.append(i.id)
    for i in ques3:
        c3.append(i.id)
    
    print(c1)
    q1=[]
    q2=[]
    q3=[]
    
    while len(q1)<4:
        import random as r
        rd=r.choice(c1)
        if rd not in q1:
            q1.append(rd)
    while len(q2)<4:
        import random as r
        rd=r.choice(c2)
        print(rd)
        if rd not in q2:
            q2.append(rd)
    while len(q3)<2:
        import random as r
        rd=r.choice(c3)
        if rd not in q3:
            q3.append(rd)
    print(q1)
    print(q2)
    print(q3)
    d1=[]
    d2=[]
    d3=[]
    for i in q1:
        global ques
        ques=Questions.objects.get(id=i)
        d1.append(ques)
    for i in q2:
        ques=Questions.objects.get(id=i)
        d2.append(ques)
    for i in q3:
        ques=Questions.objects.get(id=i)
        d3.append(ques)
    d=d1+d2+d3
    
    print(a)

    context = {
        'ques':d, 
        'cam': 'LIVE',
        'a':a
    }
    # if request.method=='POST':
    #     print(main_count)
    #     ans1=request.POST.get('ans1')
    #     ans2=request.POST.get('ans2')
    #     ans3=request.POST.get('ans3')
    #     ans4=request.POST.get('ans4')
    #     ans5=request.POST.get('ans5')
    #     ans6=request.POST.get('ans6')
    #     ans7=request.POST.get('ans7')
    #     ans8=request.POST.get('ans8')
    #     ans9=request.POST.get('ans9')
    #     ans10=request.POST.get('ans10')
    #     print(ans2)
    #     print('ans2')
    #     if ans1==d[0].correct_ans:
    #         m1=1
    #     else:
    #         m1=0
    #     if ans2==d[1].correct_ans:
    #         m2=1
    #     else:
    #         m2=0
    #     if ans3==d[2].correct_ans:
    #         m3=1
    #     else:
    #         m3=0
    #     if ans4==d[3].correct_ans:
    #         m4=1
    #     else:
    #         m4=0
    #     if ans5==d[4].correct_ans:
    #         m5=1
    #     else:
    #         m5=0
    #     if ans6==d[5].correct_ans:
    #         m6=1
    #     else:
    #         m6=0
    #     if ans7==d[6].correct_ans:
    #         m7=1
    #     else:
    #         m7=0
    #     if ans8==d[7].correct_ans:
    #         m8=1
    #     else:
    #         m8=0
    #     if ans9==d[8].correct_ans:
    #         m9=1
    #     else:
    #         m9=0
    #     if ans10==d[9].correct_ans:
    #         m10=1
    #     else:
    #         m10=0
        
    #     mark=m1+m2+m3+m4+m5+m6+m7+m8+m9+m10
    #     print(mark)
    #     print('mark')
    #     if main_count >= 10 or f_count >= 2:
    #         m=True
    #         if main_count >= 10:
    #             mc = True
    #         else:
    #             mc=False
    #         if f_count >=2:
    #             fc = True
    #         else:
    #             fc = False
    #     else:
    #         m=False
    #         mc=False
    #         fc = False
    #     print(mc,fc,m)
    #     if Result.objects.filter(stud=user,uq=ques.uq,assessment=2).exists():
    #         context={
    #             'exam':'Exam already attended,You cant attend the exam again.If any query please contact administration'
    #         }
    #         return render(request,'student/start_exam.html', context)
    #     Result(stud=user,uq=ques.uq,total_mark=mark,malpractice=m,multiple_face=fc,head_movement=mc,assessment=2).save()
    #     cv2.destroyAllWindows()
    #     context = {
    #         'msg':'SUCCESSFULLY SUBMITTED',
    #         'ques':d,
    #         'ques':d,
    #         'ans1':ans1,
    #         'ans2':ans2,
    #         'ans3':ans3,
    #         'ans4':ans4,
    #         'ans5':ans5,
    #         'ans6':ans6,
    #         'ans7':ans7,
    #         'ans8':ans8,
    #         'ans9':ans9,
    #         'ans10':ans10,
    #         'm1':m1,
    #         'm2':m2,
    #         'm3':m3,
    #         'm4':m4,
    #         'm5':m5,
    #         'm6':m6,
    #         'm7':m7,
    #         'm8':m8,
    #         'm9':m9,
    #         'm10':m10,
    #         'mark':mark
    #     }
    #     return render(request,'student/key.html',context)

    return render(request,'student/start_exam2.html', context)
    # return render(request,'student/start_exam.html',context)
def start_exam1_post(request):
    user = Student.objects.get(user=request.user)
    if request.method=='POST':
        print(main_count)
        ans1=request.POST.get('ans1')
        ans2=request.POST.get('ans2')
        ans3=request.POST.get('ans3')
        ans4=request.POST.get('ans4')
        ans5=request.POST.get('ans5')
        ans6=request.POST.get('ans6')
        ans7=request.POST.get('ans7')
        ans8=request.POST.get('ans8')
        ans9=request.POST.get('ans9')
        ans10=request.POST.get('ans10')
        print(ans2)
        print('ans2')
        if ans1==d[0].correct_ans:
            m1=1
        else:
            m1=0
        if ans2==d[1].correct_ans:
            m2=1
        else:
            m2=0
        if ans3==d[2].correct_ans:
            m3=1
        else:
            m3=0
        if ans4==d[3].correct_ans:
            m4=1
        else:
            m4=0
        if ans5==d[4].correct_ans:
            m5=1
        else:
            m5=0
        if ans6==d[5].correct_ans:
            m6=1
        else:
            m6=0
        if ans7==d[6].correct_ans:
            m7=1
        else:
            m7=0
        if ans8==d[7].correct_ans:
            m8=1
        else:
            m8=0
        if ans9==d[8].correct_ans:
            m9=1
        else:
            m9=0
        if ans10==d[9].correct_ans:
            m10=1
        else:
            m10=0
        
        mark=m1+m2+m3+m4+m5+m6+m7+m8+m9+m10
        print(mark)
        print('mark')
        if main_count >= 10 or f_count >= 2:
            m=True
            if main_count >= 10:
                mc = True
            else:
                mc=False
            if f_count >=2:
                fc = True
            else:
                fc = False
        else:
            m=False
            mc=False
            fc = False
        print(mc,fc,m)
        if Result.objects.filter(stud=user,uq=ques.uq,assessment=1).exists():
            context={
                'exam':'Exam already attended,You cant attend the exam again.If any query please contact administration'
            }
            return render(request,'student/start_exam.html', context)
        print('schin')
        print(output_video_path)
        print('blabla')
        Result(stud=user,uq=ques.uq,total_mark=mark,malpractice=m,multiple_face=fc,head_movement=mc,assessment=1,video=output_video_path).save()
        cv2.destroyAllWindows()
        context = {
            'msg':'SUCCESSFULLY SUBMITTED',
            'ques':d,
            'ques':d,
            'ans1':ans1,
            'ans2':ans2,
            'ans3':ans3,
            'ans4':ans4,
            'ans5':ans5,
            'ans6':ans6,
            'ans7':ans7,
            'ans8':ans8,
            'ans9':ans9,
            'ans10':ans10,
            'm1':m1,
            'm2':m2,
            'm3':m3,
            'm4':m4,
            'm5':m5,
            'm6':m6,
            'm7':m7,
            'm8':m8,
            'm9':m9,
            'm10':m10,
            'mark':mark
        }
        return render(request,'student/key.html',context)

    
def stud_result(request):
    user = Student.objects.get(user=request.user)
    # uq=UploadQuestions.objects.get(dept=user.dept,sem=user.dept)
    res1 = Result.objects.filter(stud=user,uq__sem=user.sem,assessment=1)
    res2 = Result.objects.filter(stud=user,uq__sem=user.sem,assessment=2)
    context = {
        'res1':res1,
        'res2':res2,
    }
    return render(request,'student/stud_result.html',context)

@require_GET
def get_subjects_by_semester(request):
    if request.method == 'GET':
        semester = request.GET.get('semester')
        department = request.GET.get('department')
        subjects = Subjects.objects.filter(semester=semester,department=department)
        data = [{'id': subject.id, 'name': subject.sub_name} for subject in subjects]
        return JsonResponse(data, safe=False)
    
    
from django.http import StreamingHttpResponse
import cv2 
import numpy as np 
import dlib 

# def live_feed1(request):
#     cap = cv2.VideoCapture(0)
#     detector = dlib.get_frontal_face_detector()

#     def video_stream():
#         f_count = 0
#         fmain_count = 0
#         count = 0
#         main_count = 0

#         while True:
#             ret, frame = cap.read() 
#             frame = cv2.flip(frame, 1) 
#             gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) 
#             faces = detector(gray)

#             i = 0

#             for face in faces: 
#                 x, y = face.left(), face.top() 
#                 x1, y1 = face.right(), face.bottom() 
#                 cv2.rectangle(frame, (x, y), (x1, y1), (0, 255, 0), 2) 
#                 i = i + 1
#                 cv2.putText(frame, 'face num' + str(i), (x-10, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
#                 if i > 1:
#                     f_count = f_count + 1
#                     if f_count == 30:
#                         fmain_count = fmain_count + 1
#                         f_count = 0

#             if len(faces) == 0:
#                 count = count + 1
#                 if count == 40:
#                     main_count = main_count + 1
#                     count = 0

#             cv2.putText(frame, f"multiple face count: {fmain_count}", (30, 50), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 2)
#             cv2.putText(frame, f"not detected: {main_count}", (10, 30), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 2)

#             if fmain_count == 5 or main_count == 20:
#                 cv2.putText(frame, "DISQUALIFIED", (120, 120), cv2.FONT_HERSHEY_PLAIN, 3, (0, 0, 255), 2)

#             cv2.imshow('frame', frame) 

#             if cv2.waitKey(1) & 0xFF == ord('q'):
#                 break

#     video_stream()
#     cap.release()
#     cv2.destroyAllWindows()

#     response = StreamingHttpResponse(video_stream(), content_type='multipart/x-mixed-replace;boundary=frame')
#     response['Cache-Control'] = 'no-store, no-cache, must-revalidate, private, max-age=0'
#     return response


'''def gen_frames():
    global f_count
    global main_count
    cap = cv2.VideoCapture(0)
    detector = dlib.get_frontal_face_detector()
    f_count = 0
    fmain_count = 0
    count = 0
    main_count = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # frame = cv2.flip(frame, 1)
        #print('a')
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector(gray)
        i = 0
        for face in faces:
            x, y = face.left(), face.top()
            x1, y1 = face.right(), face.bottom()
            cv2.rectangle(frame, (x, y), (x1, y1), (0, 255, 0), 2)
            i = i + 1
            cv2.putText(frame, 'face num' + str(i), (x-10, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            if i > 1:
                print("Multiple faces has been detected")
                f_count = f_count + 1
                if f_count == 30:
                    fmain_count = fmain_count + 1
                    f_count = 0

        if len(faces) == 0:
            print("Look into the screen")
            count = count + 1
            if count == 40:
                main_count = main_count + 1
                count = 0 
                
        cv2.putText(frame, f"multiple face count: {fmain_count}", (30, 50), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 2)
        cv2.putText(frame, f"not detected: {main_count}", (10, 30), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 2)
        # if fmain_count == 5 or main_count == 20:
        #     cv2.putText(frame, "DISQUALIFIED", (120, 120), cv2.FONT_HERSHEY_PLAIN, 3, (0, 0, 255), 2)
   
           
           
                    
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    # cap.release()'''
    


'''def gen_frames():
    global f_count
    global main_count
    cap = cv2.VideoCapture(0)
    detector = dlib.get_frontal_face_detector()
    f_count = 0
    fmain_count = 0
    count = 0
    main_count = 0
    recording = False
    out = None
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector(gray)
        i = 0
        for face in faces:
            x, y = face.left(), face.top()
            x1, y1 = face.right(), face.bottom()
            cv2.rectangle(frame, (x, y), (x1, y1), (0, 255, 0), 2)
            i = i + 1
            cv2.putText(frame, 'face num' + str(i), (x-10, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            if i > 1:
                print("Multiple faces has been detected")
                f_count = f_count + 1
                if f_count == 30:
                    fmain_count = fmain_count + 1
                    f_count = 0
                    
        
        if len(faces) == 0:
            print("Look into the screen")
            count = count + 1
            if count == 40:
                main_count = main_count + 1
                count = 0

        cv2.putText(frame, f"multiple face count: {fmain_count}", (30, 50), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 2)
        cv2.putText(frame, f"not detected: {main_count}", (10, 30), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 2)
        
        if fmain_count > 2 or main_count>10:
            recording = True
            out = cv2.VideoWriter('C:\\Users\\RESHMA\\Desktop\\Exam\\Exam\\malpractice\\output_video.avi', cv2.VideoWriter_fourcc(*'XVID'), 20.0, (frame.shape[1], frame.shape[0]))
        
        if recording:
            out.write(frame)
        
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')'''
               

import cv2
import dlib
import os
from .models import Result  # Import the Result model
from django.conf import settings

def gen_frames(a_no):
    global f_count
    global main_count
    global output_video_path
    global out
    
    cap = cv2.VideoCapture(0)
    detector = dlib.get_frontal_face_detector()

    output_video_path = os.path.join(settings.MEDIA_ROOT, f"Exam_video/output_video_{a_no}_{sss}_{aaa}.mp4")
    
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    size = (frame_width, frame_height)

    
    result = cv2.VideoWriter(output_video_path,
                         cv2.VideoWriter_fourcc(*'H264'),
                         10, size)


    f_count = 0
    fmain_count = 0
    count = 0
    main_count = 0
    recording = False
    out = None
    print(output_video_path)
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        result.write(frame)

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector(gray)
        i = 0
        for face in faces:
            x, y = face.left(), face.top()
            x1, y1 = face.right(), face.bottom()
            cv2.rectangle(frame, (x, y), (x1, y1), (0, 255, 0), 2)
            i = i + 1
            cv2.putText(frame, 'face num' + str(i), (x-10, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            if i > 1:
                print("Multiple faces has been detected")
                f_count = f_count + 1
                if f_count == 10:
                    fmain_count = fmain_count + 1
                    f_count = 0
                    # if fmain_count > 2:
                    #     recording = True
                    #     out = cv2.VideoWriter('C:\\Users\\RESHMA\\Desktop\\Exam\\Exam\\malpractice\\output_video.avi', cv2.VideoWriter_fourcc(*'XVID'), 20.0, (frame.shape[1], frame.shape[0]))
        
        if len(faces) == 0:
            print("Look into the screen")
            count = count + 1
            if count == 15:
                main_count = main_count + 1
                count = 0
                # if main_count > 10:
                #     recording = True
                #     out = cv2.VideoWriter('C:\\Users\\RESHMA\\Desktop\\Exam\\Exam\\malpractice\\output_video.avi', cv2.VideoWriter_fourcc(*'XVID'), 20.0, (frame.shape[1], frame.shape[0]))

        cv2.putText(frame, f"multiple face count: {fmain_count}", (30, 50), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 2)
        cv2.putText(frame, f"not detected: {main_count}", (10, 30), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 2)
        
        # if recording:
        #     out.write(frame)
        # if out is None:

        #     out = cv2.VideoWriter(output_video_path, cv2.VideoWriter_fourcc(*'H264'), 20.0, (frame.shape[1], frame.shape[0]))
        # out.write(frame)
        # print('annan')
        # print(output_video_path)
        # print('sir')
        
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()
        
        

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
     
        


    # result = Result.objects.create(video=output_video_path)
    # result.save()

    # return output_video_path

# Example usage
# for frame in gen_frames():
#     # Do something with the frame
#     pass


    


def video_feed(request):
    user=Student.objects.get(user=request.user)
    a_no=user.admission_no
    return StreamingHttpResponse(gen_frames(a_no), content_type='multipart/x-mixed-replace;boundary=frame')


from moviepy.editor import VideoFileClip
def play_video(request,pk):
    v=Result.objects.get(id=pk)
    video_url = v.video.url
    # if video_url.endswith('.avi'):
    #     # Define the path for the converted MP4 video
    #     converted_video_path = video_url[:-4] + '.mp4'
        
    #     # Convert AVI to MP4
    #     video_clip = VideoFileClip(video_url)
    #     video_clip.write_videofile(converted_video_path)
        
    #     # Update the video URL to the MP4 format
    #     v.video.url = converted_video_path
    
    # Pass the updated Result object to the context
    context = {'v': v}
    return render(request,'teacher/examvideo.html',context)
    

from django.conf import settings  # Import Django settings module



import os


from .models import Result

