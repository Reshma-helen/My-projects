from django.urls import path
from . import views
from .views import UploadQuestionsView,AddQuestionsView,ViewQuestions,ViewSubQuestions

urlpatterns = [
    path('',views.index,name='index'),
    
    path('register-image',views.stud_reg_image,name='register-image'),
    path('live_feed/', views.live_feed, name='live_feed'),
    path('cap',views.cap,name='cap'),
    
    path('stud-register',views.stud_register,name='stud-register'),
    path('stud-login',views.stud_login,name='stud-login'),
    path('stud-index',views.stud_index,name='stud-index'),
    path('st_changepassword',views.s_changepassword),
    path('st_profile',views.stud_profile),
    path('st_update',views.stud_update_profile),
    path('slogout',views.log_out),
    path('stud-exam',views.stud_exam,name='stud_exam'),
    path('start-verification<str:pk><int:a>',views.start_verification,name='start_verification'),
    path('start-exam1/<str:pk>/<int:a>/', views.start_exam1, name='start_exam1'),
    path('start-exam2/<str:pk>/<int:a>/', views.start_exam2, name='start_exam2'),
    path('cap1<str:pk><int:a>',views.cap1,name='cap1'),
    path('stud-result',views.stud_result,name='stud_result'),
    
    path('/start_exam1_post',views.start_exam1_post,name='start_exam1_post'),
    path('/start_exam2_post',views.start_exam2_post,name='start_exam2_post'),
    
    path('t_login',views.t_login),
    path('t_regist',views.t_reg),
    path('t_index',views.t_index,name='t_index'),
    path('t_profile',views.t_profile,name='t_profile'),
    path('t_update',views.t_update_profile),
    path('t_changepassword',views.t_changepassword,name='t_changepassword'),
    path('tlogout',views.t_logout,name='tlogout'),
    path('upload/', UploadQuestionsView.as_view(), name='upload_questions'),
    path('addupload/<str:pk>', AddQuestionsView.as_view(), name='add_questions'),
    path('delete_module/<int:pk>/', views.delete_module, name='delete_module'),
    path('tr_view_stud_result/<str:pk>/', views.tr_view_stud_result, name='tr_view_stud_result'),
    path('tr_edit_qus/<str:pk>/<str:ak>', views.tr_edit_qus, name='tr_edit_qus'),
    path('play_video<str:pk>',views.play_video,name='play_video'),
    
    path('sel_student',views.sel_stud,name='sel_student'),
    path('tr_view_question',views.teacher_viewquestion,name='tr_view_question'),
    path('view_questions',ViewQuestions.as_view(),name='view_questions'),
    path('view_sub_questions<str:pk>',ViewSubQuestions.as_view(),name='view_sub_questions'),
    path('get-subjects-by-semester/', views.get_subjects_by_semester, name='get_subjects_by_semester'),
    # path('live_feed1/', views.live_feed1, name='live_feed1'),
    path('video_feed/', views.video_feed, name='video_feed'),
    

    
]
