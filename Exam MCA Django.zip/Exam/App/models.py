from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Department(models.Model):
    dept=models.CharField(max_length=100)
    
    def __str__(self):
        return  self.dept
    

class Student(models.Model):
    choice = (
        ("waiting", "waiting"),
        ("yes", "yes"),
        ("no", "no"),
        )
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    name=models.CharField(max_length=100)
    roll_number = models.CharField(max_length=20)
    dept = models.ForeignKey(Department,on_delete = models.CASCADE)
    sem = models.CharField(max_length=100)
    batch = models.CharField(max_length=100)
    phone = models.CharField(max_length=100)
    admission_no = models.IntegerField()
    image = models.ImageField(null=True,upload_to='profile',blank=True)
    is_approved = models.CharField(max_length=100,default='waiting',choices=choice)
    
    def __str__(self):
        return  self.name
    
class Teacher(models.Model):
    choice = (
        ("waiting", "waiting"),
        ("yes", "yes"),
        ("no", "no"),
        )
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    name=models.CharField(max_length=100)
    t_id=models.CharField(max_length=25)
    dept=models.ForeignKey(Department,on_delete = models.CASCADE)
    phone=models.IntegerField()
    is_approved=models.CharField(max_length=100,default='waiting',choices=choice)
    
    def __str__(self):
        return  self.name
    

class Subjects(models.Model):
    choice = (
        ("1", "1"),
        ("2", "2"),
        ("3", "3"),
        ("4", "4"),
        )
    department = models.ForeignKey(Department,on_delete=models.CASCADE)
    semester  = models.CharField(max_length=10,choices=choice)
    sub_name = models.CharField(max_length=128)
    
    def __str__(self):
        return  self.sub_name
    
class UploadQuestions(models.Model):
    choice = (
        ("1", "1"),
        ("2", "2"),
        ("3", "3"),
        ("4", "4"),
        ("5", "5"),
        ("6", "6"),
        )
    choice2 = (
        ("1", "1"),
        ("2", "2"),
        ("3", "3"),
        ("4", "4"),
        )
    tr=models.ForeignKey(Teacher,on_delete=models.CASCADE)
    dept = models.ForeignKey(Department,on_delete=models.CASCADE)
    sub = models.ForeignKey(Subjects,on_delete=models.CASCADE)
    module = models.CharField(max_length=50,choices=choice)
    sem = models.CharField(max_length=50,choices=choice2)
    
    
    def __str__(self):
        return self.sub.sub_name

    
class Questions(models.Model):
    uq = models.ForeignKey(UploadQuestions,on_delete = models.CASCADE)
    qus1 = models.CharField(max_length=250)
    ans1 = models.CharField(max_length=200)
    ans2 = models.CharField(max_length=200)
    ans3 = models.CharField(max_length=200)
    correct_ans = models.CharField(max_length=200)
    
class Result(models.Model):
    stud = models.ForeignKey(Student,on_delete = models.CASCADE)
    uq = models.ForeignKey(UploadQuestions,on_delete = models.CASCADE)
    total_mark = models.IntegerField(null=True)
    assessment = models.IntegerField(null=True)
    malpractice = models.BooleanField(null=True,default=False)
    multiple_face = models.BooleanField(null=True,default=False)
    head_movement = models.BooleanField(null=True,default=False)
    video = models.FileField(upload_to='Exam_video_abc',null=True) 
   
    
    
                                                
        
    


