from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Student)
admin.site.register(Teacher)
admin.site.register(Department)
admin.site.register(UploadQuestions)
admin.site.register(Questions)

from django import forms
from .models import Department, Subjects

class SubjectAdminForm(forms.ModelForm):
    class Meta:
        model = Subjects
        fields = ['department', 'semester', 'sub_name']

class SubjectAdmin(admin.ModelAdmin):
    
    form = SubjectAdminForm

    def save_model(self, request, obj, form, change):
        # This method is called by Django when saving the model in the admin interface.
        # We override it to handle the custom form behavior.
        subject_names = form.cleaned_data['sub_name'].split(',')
        for name in subject_names:
            # Create a new Subject object for each subject name and save it
            Subjects.objects.create(department=form.cleaned_data['department'],
                                   semester=form.cleaned_data['semester'],
                                   sub_name=name.strip())

    def get_form(self, request, obj=None, **kwargs):
        # Override get_form to include additional form field for entering subject names
        form = super().get_form(request, obj, **kwargs)
        form.base_fields['sub_name'] = forms.CharField(widget=forms.Textarea(attrs={'rows': 4}), label='Subject Names', help_text='Enter subject names separated by commas.')
        return form

admin.site.register(Subjects, SubjectAdmin)
admin.site.register(Result  )