
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as auth_login,logout
from django.contrib import messages
from .models import *
from django.contrib.auth.decorators import login_required



# Create your views here.

def home(request):
    return render(request,'home.html')


from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User
from .models import Reg_User

def register(request):
    if request.method == "POST":
        full_name = request.POST['full_name']
        email = request.POST['email']
        phone = request.POST['phone']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']

      
        if password != confirm_password:
            messages.error(request, "⚠️ Passwords do not match!")
            return redirect('register')

        if User.objects.filter(username=email).exists():
            messages.error(request, "⚠️ Email is already registered!")
            return redirect('register')

        user = User.objects.create_user(username=email, email=email, password=password, first_name=full_name)
        user.save()

      
        Reg_User.objects.create(user=user, phone=phone)

        messages.success(request, "✅ Registration successful! Please login.")
        return redirect(log)  

    return render(request, 'register.html')




def log(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['password']
        
        try:
            user_obj = User.objects.get(username=email)
        except User.DoesNotExist:
            messages.error(request, "Email is incorrect!")
            return render(request, 'login.html')

        
        user = authenticate(request, username=email, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect(analyze_brain_ct) 
        else:
            messages.error(request, "Password is incorrect!")

    return render(request, 'login.html')



def chat(request):
    return render(request,'chat.html')



def chatnew(request):
    return render(request,'chatnew.html')



from PIL import Image
import google.generativeai as genai
import io

from django.http import JsonResponse




# Configure Gemini AI
genai.configure(api_key="AIzaSyAglCMAOG3qxK9Km5uJQ0NFtqhCA2HnXtk")  



# from django.http import JsonResponse
# from django.core.files.storage import default_storage
# from django.core.files.base import ContentFile
# import os

# def analyze_brain_ct(request):
#     if request.method == "POST":
#         user_input = request.POST.get("user-input", "").strip()
#         response_text = ""

#         image_url = None  # Default: No image uploaded

#         # If an image is uploaded, save it temporarily and process it
#         if request.FILES.get("file"):
#             file = request.FILES["file"]
#             img = Image.open(file)

#             # Save image to media folder (ensure MEDIA_URL is configured in Django)
#             file_name = default_storage.save(f"uploads/{file.name}", ContentFile(file.read()))
#             image_url = f"/media/{file_name}"  # Construct image URL for frontend display

#             # AI Prompt for Image Processing
#             prompt = f'''
#             Your role is to analyze the uploaded medical image and respond accordingly.
#             If the image contains a disease, provide:
#             - A brief description of the disease.
#             - Recommended medications.
#             - Likely causes.

#             If no disease is detected, respond:
#             "No disease observed from the given image."

#             User Query: {user_input}
#             '''

#             try:
#                 model = genai.GenerativeModel("gemini-1.5-flash")
#                 response = model.generate_content([prompt, img])
#                 response_text = response.text if response else "Error: No response generated."
#             except Exception as e:
#                 response_text = f"Error processing the request: {str(e)}"

#         # If only text input is given, process it separately
#         elif user_input:
#             # Handle greetings
#             greetings = ["hai", "hello", "hey", "good morning", "good afternoon", "good evening"]
#             if any(user_input.lower().startswith(greet) for greet in greetings):
#                 response_text = "Hello! How can I assist you with medical-related queries today?"
#             else:
#                 # AI Prompt for Medical Queries
#                 prompt = f'''
#                 Your role is to respond to medical-related user queries. 
#                 - Provide detailed medical information.
#                 - For medical law-related queries, respond properly.
#                 - If the query is **not medical-related**, reply: "I can assist you only with medical queries."

#                 User Input: {user_input}
#                 '''

#                 try:
#                     model = genai.GenerativeModel("gemini-1.5-flash")
#                     response = model.generate_content(prompt)
#                     response_text = response.text if response else "Error: No response generated."
#                 except Exception as e:
#                     response_text = f"Error processing the request: {str(e)}"



#         Reg_User(user_inp=user_input,bot_res=response_text).save()
#         # Return JSON response to AJAX call
#         return JsonResponse({
#             "user_input": user_input,
#             "response_text": response_text,
#             "image_url": image_url  # If an image was uploaded, send the URL
#         })
       

#     # Render the chat page if accessed via GET request
#     return render(request, "chat.html")



from django.http import JsonResponse
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.shortcuts import render
from django.utils.timezone import now
from PIL import Image
import os
from .models import *

def analyze_brain_ct(request):
    if request.method == "POST":
        user_input = request.POST.get("user-input", "").strip()
        response_text = ""
        image_url = None  # Default: No image uploaded
        user_image_path = None  # Path to save in DB
        user = request.user  # Get logged-in user
        
        # If an image is uploaded, save it temporarily and process it
        if request.FILES.get("file"):
            file = request.FILES["file"]
            img = Image.open(file)

            # Save image to media folder
            file_name = default_storage.save(f"uploads/{file.name}", ContentFile(file.read()))
            image_url = f"/media/{file_name}"  # Construct image URL for frontend display
            user_image_path = f"uploads/{file.name}"  # Save relative path in DB

            # AI Prompt for Image Processing
            prompt = f'''
            Your role is to analyze the uploaded medical image and respond accordingly.
            If the image contains a disease, provide:
            - A brief description of the disease.
            - Recommended medications.
            - Likely causes.

            If no disease is detected, respond:
            "No disease observed from the given image."

            User Query: {user_input}
            '''

            try:
                model = genai.GenerativeModel("gemini-1.5-flash")
                response = model.generate_content([prompt, img])
                response_text = response.text if response else "Error: No response generated."
            except Exception as e:
                response_text = f"Error processing the request: {str(e)}"

        # If only text input is given, process it separately
        elif user_input:
            greetings = ["hai", "hello", "hey", "good morning", "good afternoon", "good evening"]
            if any(user_input.lower().startswith(greet) for greet in greetings):
                response_text = "Hello! How can I assist you with medical-related queries today?"
            else:
                # AI Prompt for Medical Queries
                prompt = f'''
                Your role is to respond to medical-related user queries. 
                - Provide detailed medical information.
                - For medical law-related queries, respond properly.
                - If the query is **not medical-related**, reply: "I can assist you only with medical queries."

                User Input: {user_input}
                '''

                try:
                    model = genai.GenerativeModel("gemini-1.5-flash")
                    response = model.generate_content(prompt)
                    response_text = response.text if response else "Error: No response generated."
                except Exception as e:
                    response_text = f"Error processing the request: {str(e)}"

        # Save to Register model
        register_entry = Reg_User.objects.create(
            user=user,
            user_inp=user_input,
            bot_res=response_text,
            user_image=user_image_path,  # Save image path
            curr_date=now().date()
        )

        return JsonResponse({
            "user_input": user_input,
            "response_text": response_text,
            "image_url": image_url  # If an image was uploaded, send the URL
        })

    return render(request, "chat.html")









def logout_chat(request):
    logout(request)
    return redirect(home)


def hai(request):
    return HttpResponse("Hello")





