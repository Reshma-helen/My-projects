from django.db import models
from django.contrib.auth.models import User

    
    
class Reg_User(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)  # ForeignKey to User
    phone = models.CharField(max_length=15)  # Phone number field
    curr_date = models.CharField(max_length=10)  
    bot_res = models.TextField(null=True, blank=True)  # Increased response size
    user_inp = models.TextField(null=True, blank=True)  # Increased input size
    user_image = models.ImageField(upload_to='uploads/', null=True, blank=True)  # Image field

    def __str__(self):
        return self.user.username
