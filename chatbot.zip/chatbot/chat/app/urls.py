
from django.urls import path
from .import views

urlpatterns = [
   path('',views.home),
   path('reg', views.register, name='register'),
   path('log', views.log, name='login'),
   path('chat',views.chat),
   path('hai',views.hai),
   path('chatnew',views.chatnew),
   path('logout_chat',views.logout_chat),
  path("response", views.analyze_brain_ct,name='analyze_brain_ct'),
  #path("res", views.analyze_brain_ct),
  
]

