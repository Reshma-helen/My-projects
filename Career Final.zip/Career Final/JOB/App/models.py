from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class CompanyReg(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    industry=models.CharField(max_length=100)
    address=models.TextField(max_length=100)
    phone_no=models.IntegerField()
    licence_no=models.IntegerField()
    licence_doc=models.FileField(upload_to='upload_img')
    founded=models.DateField()
    location=models.CharField(max_length=100)
    #is_approved=models.CharField(max_length=50,default='waiting')

    APPROVE_CHOICES = (
        ('waiting', 'waiting'),
        ('yes', 'yes'),
        ('no', 'no'),
    )
    
    is_approved = models.CharField(
        max_length=50,
        choices=APPROVE_CHOICES,
        default='waiting'  # You can set a default value if you want
    )

    def __str__(self):
        return self.user.username +'  '+ self.is_approved

class ApplicationReg(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    age=models.IntegerField()
    address=models.TextField()
    phone_no=models.IntegerField()
    highest_edu=models.CharField(max_length=100)
    gender=models.CharField(max_length=100)
    image = models.FileField(upload_to='User_photos',null=True) 

    def __str__(self):
        return self.user.username

class CompanyAddJob(models.Model):
    comp=models.ForeignKey(CompanyReg,on_delete=models.CASCADE)
    job_name=models.CharField(max_length=100)
    job_exp=models.CharField(max_length=100)
    qualification=models.CharField(max_length=100)
    salary=models.CharField(max_length=100)
    job_des=models.CharField(max_length=100)
    post_date=models.DateField()
    close_date=models.DateField()
    job_skills=models.CharField(max_length=30)


class JobApply(models.Model):
    job=models.ForeignKey(CompanyAddJob,on_delete=models.CASCADE)
    user=models.ForeignKey(ApplicationReg,on_delete=models.CASCADE)
    resume=models.FileField(upload_to='upload_resume')
    first_screening_score=models.IntegerField(null=True)
    malpractice = models.BooleanField(null=True,default=False)
    multiple_face = models.BooleanField(null=True,default=False)
    head_movement = models.BooleanField(null=True,default=False)
    video = models.FileField(upload_to='Exam_video',null=True) 

   

class Questions(models.Model):
    
    question = models.CharField(max_length=200)
    ans1 = models.CharField(max_length=200)
    ans2 = models.CharField(max_length=200)
    ans3 = models.CharField(max_length=200)
    correct_answer = models.CharField(max_length=200)
    
    CATEGORY_CHOICES = (
        ('Intermediate', 'Intermediate'),
        ('Beginner', 'Beginner'),
        ('Expert', 'Expert'),
    )
    
    question_category = models.CharField(
        max_length=200,
        choices=CATEGORY_CHOICES,
        default='Intermediate'  # You can set a default value if you want
    )

    SUB_CHOICES = (
        ('Python', 'Python'),
        ('Java', 'Java'),
        ('Web development', 'Web development'),
    )
    
    ques_sub = models.CharField(
        max_length=200,
        choices=SUB_CHOICES,
        default='Python'  # You can set a default value if you want
    )

    def __str__(self):
        return self.question+" "+self.question_category

class MockQuestion(models.Model):
    user=models.ForeignKey(ApplicationReg,on_delete=models.CASCADE)
    qus1=models.CharField(max_length=100)
    ans1=models.CharField(max_length=100)
    correct_ans1=models.CharField(max_length=100)
    mark1=models.IntegerField()
    qus2=models.CharField(max_length=100)
    ans2=models.CharField(max_length=100)
    correct_ans2=models.CharField(max_length=100)
    mark2=models.IntegerField()
    qus3=models.CharField(max_length=100)
    ans3=models.CharField(max_length=100)
    correct_ans3=models.CharField(max_length=100)
    mark3=models.IntegerField()
    qus4=models.CharField(max_length=100)
    ans4=models.CharField(max_length=100)
    correct_ans4=models.CharField(max_length=100)
    mark4=models.IntegerField()
    qus5=models.CharField(max_length=100)
    ans5=models.CharField(max_length=100)
    correct_ans5=models.CharField(max_length=100)
    mark5=models.IntegerField()
    total_mark=models.IntegerField()
    


    
    
    