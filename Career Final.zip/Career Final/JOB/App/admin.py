from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(CompanyReg)
admin.site.register(Questions)
admin.site.register(ApplicationReg)
admin.site.register(JobApply)
admin.site.register(MockQuestion)
admin.site.register(CompanyAddJob)


