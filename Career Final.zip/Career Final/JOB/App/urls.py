from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.main),
    path('admin/logout', views.adminlog),
    

    # companny#################################################
    path('company_login', views.company_login),
    path('company_registration', views.company_registration),
    path('company_home', views.company_home),
    path('company_add_job', views.company_add_job),
    path('company_view_job', views.company_view_job),
    path('company_view_applications<str:pk>', views.company_view_applications,name='company_view_applications'),
    path('logout', views.log_out),
    path('comp_changepassword', views.comp_changepassword),
    path('company_profile', views.company_profile),
    path('comp_update_profile', views.comp_update_profile),
    



    # USER#######################################################
    path('user_login', views.user_login),
    path('user_registration', views.user_registration),
    path('user_home', views.user_home),
    path('user_job_applicants<str:pk>', views.user_job_applicants,name='user_job_applicants'),
    path('logout', views.log_out),
    path('use_changepassword', views.use_changepassword),
    path('user_profile', views.use_profile),  
    path('user_view_job_detail<str:pk>', views.user_view_job_detail,name='user_view_job_detail'),
    path('user_update_profile', views.user_update_profile),
    path('user_interview', views.user_interview),
    path('user_attend_interview', views.user_attent_interview),
    path('user_mock_interview_review', views.user_mock_interview_review),
    path('user_first_sreening', views.user_first_screening),
    path('job_apply_interview', views.job_apply_interview),
    path('total_mark_graph/', views.total_mark_graph, name='total_mark_graph'),
    path('study_items', views.study_items),
    path('items', views.items),
    path('resume<str:pk>', views.resume, name='resume'),
    path('userviewcompany',views.userviewcompany),
    path('usercompanyprofile<str:pk>', views.userviewcprofile, name='comp_profile'),
    
    
    path('video_feed/', views.video_feed, name='video_feed'),
    path('play_video<str:pk>',views.play_video,name='play_video'),
    
    



]
urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
