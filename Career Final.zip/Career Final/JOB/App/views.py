from django.shortcuts import render,redirect
from .models import *
from django.contrib.auth.models import User,auth
from django.contrib.auth import logout
from django.contrib.auth.hashers import check_password
from django.http import FileResponse
# Create your views here.
# companny#################################################
def main(request):
    return render (request,'main.html')

def adminlog(request):
    logout(request)
    return redirect('')

def company_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        # Check if the username exists in the CompanyReg model
        if CompanyReg.objects.filter(user__username=username).exists():
            comp = CompanyReg.objects.get(user__username=username)
            print(comp.is_approved)
            
            # Check if the account is approved
            if comp.is_approved == 'yes':
                u = auth.authenticate(username=username, password=password)
                
                if u is not None:
                    # Login if both username and password are correct
                    auth.login(request, u)
                    return redirect(company_home)
                else:
                    # If password is incorrect
                    context = {
                        'key': 'Invalid Password'
                    }
                    return render(request, 'company_login.html', context)
            
            elif comp.is_approved == 'no':
                context = {
                    'key': 'User is rejected'
                }
                return render(request, 'company_login.html', context)
            else:
                context = {
                    'key': 'Waiting'
                }
                return render(request, 'company_login.html', context)
        
        else:
            # If username does not exist
            context = {
                'key': 'Invalid User Name'
            }
            return render(request, 'company_login.html', context)

    return render(request, 'company_login.html')





def company_registration(request):
    if request.method=='POST':
        print('hai')
        cmp_name=request.POST['cmp_name']
        email=request.POST['email']
        industry=request.POST['industry']
        address=request.POST['address']
        password=request.POST['password']
        phone_no=request.POST['phone_no']
        licence_no=request.POST['licence_no']
        licence_doc=request.FILES['licence_doc']
        founded=request.POST['founded']
        location=request.POST['location']
        confirm_password=request.POST['confirm_password']
        if password==confirm_password:
            if CompanyReg.objects.filter(user__username=cmp_name).exists() or User.objects.filter(username=cmp_name).exists():
                context ={
                    'key':'name already exists'
                }
                return render(request,'company_registration.html',context)
            elif CompanyReg.objects.filter(user__email=email).exists() or User.objects.filter(email=email).exists():
                context ={
                    'key2':'email already exists'
                }
                return render(request,'company_registration.html',context)
            else:
                User.objects.create_user(username=cmp_name,email=email,password=password).save()
                user=User.objects.get(username=cmp_name)
                CompanyReg(user=user,industry=industry,address=address,phone_no=phone_no,licence_no=licence_no,licence_doc=licence_doc,founded=founded,location=location).save()
                # context ={
                #     'key1':'successfully register '
                # }
                # return render(request,'company_registration.html',context)
                return redirect(company_login)

        else:
            context ={
                'key3':'Password does not match',
                
            }
            return render(request,'company_registration.html',context)
    return render(request,'company_registration.html')

def company_home(request):
    comp=CompanyReg.objects.get(user=request.user)
    context = {
        'key':comp,
    }
    return render(request,'company_home.html',context)

def company_add_job(request):
    comp=CompanyReg.objects.get(user=request.user)
    context = {
        'key':comp
    }

    if request.method=='POST':
        job_name=request.POST['job_name']
        job_exp=request.POST['job_exp']
        qualification=request.POST['qualification']
        salary=request.POST['salary']
        job_des=request.POST['job_des']
        post_date=request.POST['post_date']
        close_date=request.POST['close_date']
        job_skill=request.POST['job_skills']
        CompanyAddJob(comp=comp,job_name=job_name,job_exp=job_exp,qualification= qualification,salary=salary,job_des=job_des,post_date=post_date,close_date=close_date,job_skills=job_skill).save()
        context ={
            'key':comp,
            'key1':'Successfully uploaded'
        }
        return render(request,'company_add_job.html',context)
    
    return render(request,'company_add_job.html',context)
    
def company_view_job(request):
    jobs=CompanyAddJob.objects.filter(comp__user=request.user).order_by('-id')
    context = {
        'job':jobs
    }
    return render(request,'company_view_job.html',context)

def company_view_applications(request,pk):
    applications=JobApply.objects.filter(job=pk)
    if request.method=='POST':
        val=request.POST['val']
        app=applications.filter(first_screening_score__gte=val)
        context = {
        'app':app
        
        }
        return render(request,'company_view_applications.html',context)
        
    context = {
        'app':applications
        
    }
    return render(request,'company_view_applications.html',context)




# USER#######################################################
def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        # Check if the username exists in the ApplicationReg model
        if ApplicationReg.objects.filter(user__username=username).exists():
            # Authenticate the user to check if the password is correct
            u = auth.authenticate(username=username, password=password)
            
            if u is not None:
                # Login if both username and password are correct
                auth.login(request, u)
                return redirect(user_home)
            else:
                # If the password is incorrect
                context = {
                    'log': "Invalid Password"
                }
                return render(request, 'user_login.html', context)
        
        else:
            # If the username does not exist
            context = {
                'log': "Invalid User Name"
            }
            return render(request, 'user_login.html', context)
    
    return render(request, 'user_login.html')

        


def user_registration(request):
    if request.method=='POST':
        print('hai')
        first_name=request.POST['first_name']
        user_name=request.POST['user_name']
        email=request.POST['email']
        age=request.POST['age']
        last_name=request.POST['last_name']
        phone_no=request.POST['phone_no']
        highest_edu=request.POST['highest_edu']
        gender=request.POST['gender']
        address=request.POST['address']
        password=request.POST['password']
        confirm_password=request.POST['confirm_password']
        up_img=request.FILES['up_img']
        if password==confirm_password:
            if ApplicationReg.objects.filter(user__username=user_name).exists() or User.objects.filter(username=user_name).exists():
                context ={
                    'key':'Username already exists'
                }
                return render(request,'user_registration.html',context)
            elif ApplicationReg.objects.filter(user__email=email).exists() or User.objects.filter(email=email).exists():
                context ={
                    'key1':'Email already exists'
                }
                return render(request,'user_registration.html',context)
            else:
                User.objects.create_user(username=user_name,first_name=first_name,last_name=last_name,email=email,password=password).save()
                user=User.objects.get(username=user_name)
                ApplicationReg(user=user,age=age,highest_edu=highest_edu,phone_no=phone_no,address=address,gender=gender,image=up_img).save()
                # context ={
                #     'key':'successfully register '
                # }
                # return render(request,'user_registration.html',context)
                return redirect(user_login)

        else:
            context ={
                'key2':'password does not match'
            }
            return render(request,'user_registration.html',context)
    return render(request,'user_registration.html')

####################################################################################################
def user_home(request):
    job=CompanyAddJob.objects.all().order_by('-id')
    context = {
        'job':job
    }
    if request.method=='POST':
        comp_search=request.POST['comp_search']
        if CompanyAddJob.objects.filter(job_name__icontains=comp_search).exists():
            comp_job=CompanyAddJob.objects.filter(job_name__icontains=comp_search).order_by('-id') 
            context = {
                'job':comp_job
            }           
            return render(request,'user_home.html',context) 
        else:
            context = {
                'msg':'no jobs or company posted yet'
            }
            return render(request,'user_home.html',context)           
    return render(request,'user_home.html',context)    

################################################################################################# 

def user_view_job_detail(request,pk):
    job=CompanyAddJob.objects.get(id=pk)
    context = {
        'job':job
    }
    return render(request,'user_view_job_detail.html',context) 



def user_job_applicants(request,pk):
    job=CompanyAddJob.objects.get(id=pk)
    user=ApplicationReg.objects.get(user=request.user)
    context = {
        'data':user
    }
    if request.method=='POST':
        print('hai')
        print('hai')
        print('hai')
        r=request.FILES['res']
        if JobApply.objects.filter(job=job,user=user).exists():
            context = {
                'data':user,
                'msg':'Already applied'
            }
            return render(request,'user_job_applicants.html',context)
        else:
            JobApply(job=job,user=user,resume=r).save()

            global d,jobs_apply
            jobs_apply=JobApply.objects.get(job=job,user=user)
            skills=jobs_apply.job.job_skills
            c1=[]
            c2=[]
            c3=[]
            ques1=Questions.objects.filter(ques_sub=skills,question_category='Intermediate')
            ques2=Questions.objects.filter(ques_sub=skills,question_category='Beginner')
            ques3=Questions.objects.filter(ques_sub=skills,question_category='Expert')
            for i in ques1:
                c1.append(i.id)
            for i in ques2:
                c2.append(i.id)
            for i in ques3:
                c3.append(i.id)
            # b=len(ques)
            q1=[]
            q2=[]
            q3=[]
            
            while len(q1)<4:
                import random as r
                rd=r.choice(c1)
                if rd not in q1:
                    q1.append(rd)
            while len(q2)<2:
                import random as r
                rd=r.choice(c2)
                print(rd)
                if rd not in q2:
                    q2.append(rd)
            while len(q3)<4:
                import random as r
                rd=r.choice(c3)
                if rd not in q3:
                    q3.append(rd)
            d1=[]
            d2=[]
            d3=[]
            for i in q1:
                ques=Questions.objects.get(id=i)
                d1.append(ques)
            for i in q2:
                ques=Questions.objects.get(id=i)
                d2.append(ques)
            for i in q3:
                ques=Questions.objects.get(id=i)
                d3.append(ques)
            d=d1+d2+d3
            # for i in d:
            #     print(i.question)
            #     print(i.ans1)
            context = {
                'ques':d,
                
            }

            ########
            
            ######
            return render(request,'user_first_screening.html',context)
    return render(request,'user_job_applicants.html',context)
    
    

    
###########################################################################################################################

def user_first_screening(request):
    return render(request,'user_first_screening.html')

def job_apply_interview(request):
    user = ApplicationReg.objects.get(user=request.user)
    global jobs_apply
    if request.method=='POST':
        ans1=request.POST.get('ans1')
        ans2=request.POST.get('ans2')
        ans3=request.POST.get('ans3')
        ans4=request.POST.get('ans4')
        ans5=request.POST.get('ans5')
        ans6=request.POST.get('ans6')
        ans7=request.POST.get('ans7')
        ans8=request.POST.get('ans8')
        ans9=request.POST.get('ans9')
        ans10=request.POST.get('ans10')
        if ans1==d[0].correct_answer:
            m1=1
        else:
            m1=0
        if ans2==d[1].correct_answer:
            m2=1
        else:
            m2=0
        if ans3==d[2].correct_answer:
            m3=1
        else:
            m3=0
        if ans4==d[3].correct_answer:
            m4=1
        else:
            m4=0
        if ans5==d[4].correct_answer:
            m5=1
        else:
            m5=0
        if ans6==d[5].correct_answer:
            m6=1
        else:
            m6=0
        if ans7==d[6].correct_answer:
            m7=1
        else:
            m7=0
        if ans8==d[7].correct_answer:
            m8=1
        else:
            m8=0
        if ans9==d[8].correct_answer:
            m9=1
        else:
            m9=0
        if ans10==d[9].correct_answer:
            m10=1
        else:
            m10=0
        
        mark=m1+m2+m3+m4+m5+m6+m7+m8+m9+m10
        
        if main_count >= 10 or f_count >= 2:
            m=True
            if main_count >= 10:
                mc = True
            else:
                mc=False
            if f_count >=2:
                fc = True
            else:
                fc = False
        else:
            m=False
            mc=False
            fc = False  
        print(mc,fc,m)
       
       # Malpractice(user1=user,job=jobs_apply,malpractice=m,multiple_face=fc,head_movement=mc).save()
        jobs_apply.malpractice = m
        jobs_apply.multiple_face=fc
        jobs_apply.head_movement=mc
        jobs_apply.video=output_video_path
        jobs_apply.save()
        
        result.release()
        
        
       
        
        
        try:
            jobs_apply.first_screening_score = mark
            jobs_apply.save()
        except Exception as e:
            print("Error while saving: ", str(e))
        
        context = {
            'ques':d,
            'ans1':ans1,
            'ans2':ans2,
            'ans3':ans3,
            'ans4':ans4,
            'ans5':ans5,
            'ans6':ans6,
            'ans7':ans7,
            'ans8':ans8,
            'ans9':ans9,
            'ans10':ans10,
            'm1':m1,
            'm2':m2,
            'm3':m3,
            'm4':m4,
            'm5':m5,
            'm6':m6,
            'm7':m7,
            'm8':m8,
            'm9':m9,
            'm10':m10,
            'mark':mark,
            'msg':'Successfully submitted your job application'

        }
        return render (request,'user_mock_interview_review.html',context)

def log_out(request):
    logout(request)
    return redirect(main)

def log_out(request):
    logout(request)
    return redirect(main)
def comp_changepassword(request):
    comp=User.objects.get(username=request.user)
    if request.method=='POST':
        currentpassword=request.POST['current_password']
        newpasssword=request.POST['new_password']
        confirmpasssword=request.POST['confirm_password']
        if newpasssword == confirmpasssword:
            print(comp.password)
            checkpassword=check_password(currentpassword,comp.password)
            print(checkpassword)
            if checkpassword==True:
                comp.set_password(newpasssword)
                comp.save()
                u=auth.authenticate(username=comp.username,password=newpasssword)
                logout(request)
                print(u)
                auth.login(request,u)
                context = {
                    'msg1':'Password changed successfully'
                }
                return render(request,"comp_changepassword.html",context)
            else:
                context = {
                    'msg':'Current password is not correct'
                }
            return render(request,"comp_changepassword.html",context)
        else:
            context = {
                'msg':'Password does not match'
            }
            return render(request,"comp_changepassword.html",context)
    return render(request,"comp_changepassword.html")

def company_profile(request):
    comp=CompanyReg.objects.get(user=request.user)
    context = {
        'comp':comp
    }
    return render(request,'company_profile.html',context)

def use_changepassword(request):
    use=User.objects.get(username=request.user)
    if request.method=='POST':
        currentpassword=request.POST['current_password']
        newpasssword=request.POST['new_password']
        confirmpasssword=request.POST['confirm_password']
        if newpasssword == confirmpasssword:
            print(use.password)
            checkpassword=check_password(currentpassword,use.password)
            print(checkpassword)
            if checkpassword==True:
                use.set_password(newpasssword)
                use.save()
                u=auth.authenticate(username=use.username,password=newpasssword)
                logout(request)
                print(u)
                auth.login(request,u)
                context = {
                    'k':'Password changed successfully'
                }
                return render(request,"use_changepassword.html",context)
            else:
                context = {
                    'k1':'Current password is not correct'
                }
            return render(request,"use_changepassword.html",context)
        else:
            context = {
                'k1':'Password does not match'
            }
            return render(request,"use_changepassword.html",context)
    return render(request,"use_changepassword.html")


def use_profile(request):
    use=ApplicationReg.objects.get(user=request.user)
    context = {
        'use':use
    }
    return render(request,'user_profile.html',context)
def user_update_profile(request):
    use=ApplicationReg.objects.get(user=request.user)
    context = {
        'use':use
    }
    user=User.objects.get(username=request.user)
    if request.method=='POST':
        user.first_name=request.POST['first_name']
        user.last_name=request.POST['last_name']
        user.username=request.POST['username']
        user.email=request.POST['email']
        use.address=request.POST['address']
        use.age=request.POST['age']
        use.phone_no=request.POST['p_no']
        use.gender=request.POST['gender']
        user.save()
        use.save()
        

        return redirect(use_profile)
    return render(request,"user_update_profile.html",context)

def comp_update_profile(request):
    comp=CompanyReg.objects.get(user=request.user)
    context = {
        'comp': comp
          }
    user=User.objects.get(username=request.user)
    if request.method=='POST':
        user.username=request.POST['comp_name']
        user.email=request.POST['email']
        comp.address=request.POST['address']
        comp.industry=request.POST['industry']
        comp.founded=request.POST['found']
        comp.phone_no=request.POST['ph_no']
        comp.location=request.POST['location']
        user.save()
        comp.save()
       
        return redirect(company_profile)
    return render(request,"comp_update_profile.html",context)


def user_interview (request):
    global d
    user=ApplicationReg.objects.get(user=request.user)
    if request.method=='POST':
        skills=request.POST['skills']
        mode=request.POST['mode']
        print(skills)
        print(mode)
        c=[]
        ques=Questions.objects.filter(ques_sub=skills,question_category=mode)
        for i in ques:
            c.append(i.id)
        print(c)
        b=len(ques)
        q=[]
        # print('hai')
        # print(b)
        while len(q)<10:
            import random as r
            rd=r.choice(c)
            print(rd)
            if rd not in q:
                q.append(rd)
        print(q)
        d=[]
        for i in q:
            ques=Questions.objects.get(id=i)
            d.append(ques)
    
        context = {
            'ques':d,
            
        }
        print(00000000000000000)
        print(d[1].question)
        return render (request,'user_attend_interview.html',context)

    return render (request,'user_interview.html')

def user_attent_interview(request):
    global d
    user=ApplicationReg.objects.get(user=request.user)

    if request.method=='POST':
        ans1=request.POST.get('ans1')
        ans2=request.POST.get('ans2')
        ans3=request.POST.get('ans3')
        ans4=request.POST.get('ans4')
        ans5=request.POST.get('ans5')
        ans6=request.POST.get('ans6')
        ans7=request.POST.get('ans7')
        ans8=request.POST.get('ans8')
        ans9=request.POST.get('ans9')
        ans10=request.POST.get('ans10')
        

        if ans1==d[0].correct_answer:
            print(ans1)
            print(d[0].correct_answer)
            m1=1
        else:
            m1=0
        if ans2==d[1].correct_answer:
            print(ans1)
            print(d[1].correct_answer)
            m2=1
        else:
            m2=0
        if ans3==d[2].correct_answer:
            print(ans1)
            print(d[2].correct_answer)
            m3=1
        else:
            m3=0
        if ans4==d[3].correct_answer:
            print(ans1)
            print(d[3].correct_answer)
            m4=1
        else:
            m4=0
        if ans5==d[4].correct_answer:
            print(ans1)
            print(d[4].correct_answer)
            m5=1
        else:
            m5=0

        if ans6==d[5].correct_answer:
            print(ans1)
            print(d[5].correct_answer)
            m6=1
        else:
            m6=0

        if ans7==d[6].correct_answer:
            print(ans1)
            print(d[6].correct_answer)
            m7=1
        else:
            m7=0

        if ans8==d[7].correct_answer:
            print(ans1)
            print(d[4].correct_answer)
            m8=1
        else:
            m8=0

        if ans9==d[8].correct_answer:
            print(ans1)
            print(d[4].correct_answer)
            m9=1
        else:
            m9=0

        if ans10==d[9].correct_answer:
            print(ans1)
            print(d[4].correct_answer)
            m10=1
        else:
            m10=0
        mark=m1+m2+m3+m4+m5+m6+m7+m8+m9+m10
        MockQuestion(user=user,qus1=d[0].question,qus2=d[1].question,qus3=d[2].question,qus4=d[3].question,qus5=d[4].question,mark1=m1,mark2=m2,mark3=m3,mark4=m4,mark5=m5,total_mark=mark,ans1=ans1,correct_ans1=d[0].correct_answer,ans2=ans2,correct_ans2=d[1].correct_answer,ans3=ans3,correct_ans3=d[2].correct_answer,ans4=ans4,correct_ans4=d[3].correct_answer,ans5=ans5,correct_ans5=d[4].correct_answer).save()
        context = {
            'ques':d,
            'ans1':ans1,
            'ans2':ans2,
            'ans3':ans3,
            'ans4':ans4,
            'ans5':ans5,
            'ans6':ans6,
            'ans7':ans7,
            'ans8':ans8,
            'ans9':ans9,
            'ans10':ans10,
            'm1':m1,
            'm2':m2,
            'm3':m3,
            'm4':m4,
            'm5':m5,
            'm6':m6,
            'm7':m7,
            'm8':m8,
            'm9':m9,
            'm10':m10,
            'mark':mark

        }
        return render (request,'user_mock_interview_review.html',context)

    return render (request,'user_attend_interview.html')

def user_mock_interview_review(request):

    return render (request,'user_mock_interview_review.html')

def study_items(request):
    if request.method=='POST':
        topic=request.POST['topic']
        items=Questions.objects.filter(ques_sub=topic)
        context = {
            'items':items
        }
        return render (request,'items.html',context)
    return render (request,'study_items.html')


def items(request):
    return render (request,'items.html')

def resume(request,pk):
    r=JobApply.objects.get(id=pk).resume.path
    return FileResponse(open(r,'rb'),content_type='application/pdf')

import matplotlib.pyplot as plt
from io import BytesIO
import base64

def total_mark_graph(request):
    user=ApplicationReg.objects.get(user=request.user)
    data = MockQuestion.objects.filter(user=user)
    user_ids = [entry.id for entry in data]
    total_marks = [entry.total_mark for entry in data]

    plt.figure(figsize=(10, 6))
    plt.plot(user_ids, total_marks, marker='o', linestyle='-')
    plt.xlabel('User')
    plt.ylabel('Total Mark')
    plt.title('Total Marks by User ')
    plt.grid(True)

    # Save the plot to a BytesIO object
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_data = base64.b64encode(buffer.read()).decode()
    plt.close()
    return render(request, 'total_mark_graph.html', {'image_data': image_data})


def userviewcompany(request):
    comp=CompanyReg.objects.filter(is_approved="yes")
    c={'key':comp}
    return render(request,'user_view_company.html',c)

def userviewcprofile(request,pk):
    compp=CompanyReg.objects.get(id=pk)
    c1={'key1':compp}
    return render(request,'user_company_profile_view.html',c1)

######################################################################################################################
from django.http import JsonResponse, StreamingHttpResponse


import cv2
import dlib
import os
from django.conf import settings



def gen_frames(a_no):
    global f_count
    global main_count
    global output_video_path
    global out
    global result

    cap = cv2.VideoCapture(0)
    detector = dlib.get_frontal_face_detector()

    # Ensure the directory exists
    exam_video_dir = os.path.join(settings.MEDIA_ROOT, "Exam_video")
    if not os.path.exists(exam_video_dir):
        os.makedirs(exam_video_dir)

    # Use 'XVID' codec and save as .avi to avoid codec issues
    output_video_path = os.path.join(exam_video_dir, f"output_video_{a_no}.mp4")

    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    size = (frame_width, frame_height)

    result = cv2.VideoWriter(
        output_video_path,
        cv2.VideoWriter_fourcc(*'H264'),  # Changed codec
        10, size
    )

    if not result.isOpened():
        print(f"Failed to open VideoWriter with path: {output_video_path}")
        #cap.release()
        return  # Exit the generator

    f_count = 0
    fmain_count = 0
    count = 0
    main_count = 0

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            result.write(frame)

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = detector(gray)
            i = 0
            for face in faces:
                x, y = face.left(), face.top()
                x1, y1 = face.right(), face.bottom()
                cv2.rectangle(frame, (x, y), (x1, y1), (0, 255, 0), 2)
                i += 1
                cv2.putText(frame, f'face num {i}', (x-10, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                if i > 1:
                    print("Multiple faces have been detected")
                    f_count += 1
                    if f_count == 10:
                        fmain_count += 1
                        f_count = 0

            if len(faces) == 0:
                print("Look into the screen")
                count += 1
                if count == 15:
                    main_count += 1
                    count = 0

            cv2.putText(frame, f"multiple face count: {fmain_count}", (30, 50), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 2)
            cv2.putText(frame, f"not detected: {main_count}", (10, 30), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 2)

            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()

            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    
        print(f"Video saved successfully at: {output_video_path}")
    except Exception as e:
        print(f"Error occurred in detection:{e}")

###############################################################################

def video_feed(request):
    user = ApplicationReg.objects.get(user=request.user)
    a_no = user.id
    return StreamingHttpResponse(gen_frames(a_no), content_type='multipart/x-mixed-replace;boundary=frame')

from moviepy.editor import VideoFileClip




def play_video(request, pk):
    v = JobApply.objects.get(id=pk)
    video_url = v.video.url
    context = {'v': v}
    return render(request, 'examvideo.html', context)
